import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  MainTab,
  HomeSideNav,
  ServerAsset,
  TradeRecord,
  ActivityItem,
  UserProfile,
  SettingsState,
  AdCampaign,
  OwnedServerStock,
} from './types';
import {
  SERVERS,
  IPO_SERVERS,
  SQUAD_CANDLES,
  ORDER_BOOK_ASKS,
  ORDER_BOOK_BIDS,
  INITIAL_TRADES,
  INITIAL_ACTIVITIES,
  INITIAL_TRADER_LEADERBOARD,
  INITIAL_SERVER_LEADERBOARD,
  INITIAL_USER_PROFILE,
  DEFAULT_SETTINGS,
  INITIAL_CAMPAIGNS,
  INITIAL_OWNED_SERVER,
} from './data/mockData';
import { TopBar } from './components/TopBar';
import { ProjectLandingView } from './components/ProjectLandingView';
import { HomeView } from './components/HomeView';
import { ExchangeView } from './components/ExchangeView';
import { ManageStockView } from './components/ManageStockView';
import { WalletView } from './components/WalletView';
import { LeaderboardView } from './components/LeaderboardView';
import { PortfolioView } from './components/PortfolioView';
import { SettingsView } from './components/SettingsView';
import { DiscordLoginView } from './components/DiscordLoginView';
import { AdCreatorView } from './components/AdCreatorView';
import { ActionModals } from './components/ActionModals';

export default function App() {
  const [activeTab, setActiveTab] = useState<MainTab>('Home');
  const [homeSideNav, setHomeSideNav] = useState<HomeSideNav>('Dashboard');
  const [servers, setServers] = useState<ServerAsset[]>(SERVERS);
  const [ipoServers] = useState<ServerAsset[]>(IPO_SERVERS);
  const [selectedServerId, setSelectedServerId] = useState<string>('squad');
  const [ownedServer, setOwnedServer] = useState<OwnedServerStock>(INITIAL_OWNED_SERVER);

  // Balances
  const [credDelta, setCredDelta] = useState<number>(0);
  const [inrBalance, setInrBalance] = useState<number>(156.0);

  // User Profile & Settings
  const [user, setUser] = useState<UserProfile>(INITIAL_USER_PROFILE);
  const [settings, setSettings] = useState<SettingsState>(DEFAULT_SETTINGS);
  const [campaigns, setCampaigns] = useState<AdCampaign[]>(INITIAL_CAMPAIGNS);

  const [trades, setTrades] = useState<TradeRecord[]>(INITIAL_TRADES);
  const [activities, setActivities] = useState<ActivityItem[]>(INITIAL_ACTIVITIES);
  const [watchlist, setWatchlist] = useState<string[]>(['squad', 'ai']);
  const [joinedServers, setJoinedServers] = useState<string[]>([]);
  const [activeModal, setActiveModal] = useState<'boost' | 'video' | 'withdraw' | 'ad' | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const homeCredBalance = Math.max(0, 1250 + credDelta);
  const exchangeCredBalance = Math.max(0, 2450 + credDelta);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? null : prev));
    }, 3200);
  };

  const allCombinedServers = [...servers, ...ipoServers];
  const selectedServer =
    allCombinedServers.find((s) => s.id === selectedServerId) ||
    servers.find((s) => s.id === 'squad')!;

  const handleSelectServerForTrade = (serverId: string) => {
    setSelectedServerId(serverId);
    setActiveTab('Exchange');
  };

  const handlePlaceOrder = (side: 'buy' | 'sell', amount: number, priceUsd: number) => {
    const now = new Date();
    const timeStr = [now.getHours(), now.getMinutes(), now.getSeconds()]
      .map((n) => String(n).padStart(2, '0'))
      .join(':');

    const newTrade: TradeRecord = {
      id: `t-${Date.now()}`,
      price: priceUsd,
      amount,
      time: timeStr,
      side,
    };
    setTrades((prev) => [newTrade, ...prev.slice(0, 5)]);

    const costCred = Math.round(amount * 12);
    setCredDelta((prev) => (side === 'buy' ? prev - costCred : prev + costCred));

    setServers((prev) =>
      prev.map((srv) => {
        if (srv.id !== selectedServer.id) return srv;
        const currentHoldings = srv.holdings ?? 24320;
        return {
          ...srv,
          holdings: side === 'buy' ? currentHoldings + amount : Math.max(0, currentHoldings - amount),
        };
      })
    );

    const newActivity: ActivityItem = {
      id: `act-${Date.now()}`,
      title: `${side === 'buy' ? 'Bought' : 'Sold'} ${selectedServer.ticker} Shares`,
      subtitle: `${side === 'buy' ? '-' : '+'}${costCred} $CRED`,
      isPositive: side === 'sell',
      timeAgo: 'Just now',
      type: side,
    };
    setActivities((prev) => [newActivity, ...prev.slice(0, 4)]);
    showToast(
      `${side === 'buy' ? 'Bought' : 'Sold'} ${amount.toLocaleString()} ${
        selectedServer.ticker
      } at $${priceUsd.toFixed(2)}`
    );
  };

  const handleToggleWatchlist = (serverId: string) => {
    setWatchlist((prev) => {
      const exists = prev.includes(serverId);
      showToast(exists ? `Removed from watchlist` : `Added to watchlist ⭐`);
      return exists ? prev.filter((id) => id !== serverId) : [...prev, serverId];
    });
  };

  const handleToggleJoinServer = (serverId: string) => {
    const srv = allCombinedServers.find((s) => s.id === serverId);
    const alreadyJoined = joinedServers.includes(serverId);
    setJoinedServers((prev) =>
      alreadyJoined ? prev.filter((id) => id !== serverId) : [...prev, serverId]
    );
    showToast(
      alreadyJoined
        ? `Left ${srv?.ticker || 'Discord'} community`
        : `Joined ${srv?.ticker || 'Discord'} server! +50 $CRED welcome bonus`
    );
    if (!alreadyJoined) {
      setCredDelta((prev) => prev + 50);
    }
  };

  const handleCompleteBoost = (serverId: string) => {
    const srv = servers.find((s) => s.id === serverId);
    setCredDelta((prev) => prev + 250);
    setInrBalance((prev) => +(prev + 3.5).toFixed(2));
    setActivities((prev) => [
      {
        id: `boost-${Date.now()}`,
        title: `Boosted ${srv?.ticker || '$SQUAD'} Stock`,
        subtitle: '+250 $CRED + ₹3.50',
        isPositive: true,
        timeAgo: 'Just now',
        type: 'boost',
      },
      ...prev.slice(0, 4),
    ]);
    showToast(`Boosted ${srv?.ticker || '$SQUAD'}! Earned +250 $CRED & +₹3.50`);
  };

  const handleCompleteVideo = () => {
    setCredDelta((prev) => prev + 250);
    setInrBalance((prev) => +(prev + 3.5).toFixed(2));
    setActivities((prev) => [
      {
        id: `vid-${Date.now()}`,
        title: 'Daily Boost Reward',
        subtitle: '+250 $CRED + ₹3.50',
        isPositive: true,
        timeAgo: 'Just now',
        type: 'boost',
      },
      ...prev.slice(0, 4),
    ]);
    showToast('Ad completed! +250 $CRED + ₹3.50 added to your wallet');
  };

  const handleCompleteWithdraw = (amount: number, upiId: string) => {
    setInrBalance((prev) => Math.max(0, +(prev - amount).toFixed(2)));
    setActivities((prev) => [
      {
        id: `wd-${Date.now()}`,
        title: `Withdrawal to UPI (${upiId})`,
        subtitle: `-₹${amount.toFixed(2)}`,
        isPositive: false,
        timeAgo: 'Just now',
        type: 'withdraw',
      },
      ...prev.slice(0, 4),
    ]);
    showToast(`₹${amount.toFixed(2)} withdrawn to ${upiId}`);
  };

  const handleCompleteAd = (serverTicker: string, budgetCred: number) => {
    setCredDelta((prev) => prev - budgetCred);
    setActivities((prev) => [
      {
        id: `ad-${Date.now()}`,
        title: `Ad Campaign (${serverTicker})`,
        subtitle: `-${budgetCred} $CRED`,
        isPositive: false,
        timeAgo: 'Just now',
        type: 'ad',
      },
      ...prev.slice(0, 4),
    ]);

    const newCamp: AdCampaign = {
      id: `camp-${Date.now()}`,
      ticker: serverTicker,
      serverName: `${serverTicker.replace('$', '')} Community`,
      tagline: 'Join our verified community and earn Cordchain dividends.',
      budgetCred,
      spentCred: 0,
      impressions: 0,
      clicks: 0,
      status: 'active',
      createdAt: 'Just now',
    };
    setCampaigns((prev) => [newCamp, ...prev]);
    showToast(`Ad campaign for ${serverTicker} launched with ${budgetCred} $CRED`);
  };

  return (
    <div className="min-h-screen bg-[#F7F6F3] text-[#18181B]">
      {/* Top Navigation Bar */}
      <TopBar
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          if (tab === 'Dashboard') setHomeSideNav('Dashboard');
        }}
        servers={allCombinedServers}
        onSelectServer={setSelectedServerId}
        credBalance={activeTab === 'Exchange' ? exchangeCredBalance : homeCredBalance}
        inrBalance={inrBalance}
        user={user}
        onOpenDiscordLogin={() => setActiveTab('Login')}
      />

      {/* Animated Page Transitions */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 7 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -7 }}
          transition={{ duration: 0.16, ease: 'easeOut' }}
        >
          {activeTab === 'Home' && (
            <ProjectLandingView
              servers={servers}
              onSelectTab={setActiveTab}
              onSelectServerForTrade={handleSelectServerForTrade}
              onOpenDiscordLogin={() => setActiveTab('Login')}
            />
          )}

          {activeTab === 'Dashboard' && (
            <HomeView
              servers={servers}
              ipoServers={ipoServers}
              activities={activities}
              credBalance={homeCredBalance}
              inrBalance={inrBalance}
              activeSideNav={homeSideNav}
              onSelectSideNav={(nav) => {
                setHomeSideNav(nav);
                if (nav === 'Ad Creator') {
                  setActiveTab('Settings');
                } else if (nav === 'Manage') {
                  setActiveTab('Manage');
                }
              }}
              onSelectTab={setActiveTab}
              onSelectServerForTrade={handleSelectServerForTrade}
              onOpenBoostModal={(ticker) => {
                if (ticker) {
                  const s = servers.find((item) => item.ticker.toLowerCase() === ticker.toLowerCase());
                  if (s) setSelectedServerId(s.id);
                }
                setActiveModal('boost');
              }}
              onOpenVideoModal={() => setActiveModal('video')}
              onOpenWithdrawModal={() => setActiveModal('withdraw')}
              onOpenAdModal={() => setActiveModal('ad')}
              onOpenDiscordLogin={() => setActiveTab('Login')}
              joinedServers={joinedServers}
              onToggleJoinServer={handleToggleJoinServer}
            />
          )}

          {activeTab === 'Manage' && (
            <ManageStockView
              ownedServer={ownedServer}
              onUpdateOwnedServer={(updated) => setOwnedServer((prev) => ({ ...prev, ...updated }))}
              onSelectTab={setActiveTab}
              onTriggerToast={showToast}
            />
          )}

          {activeTab === 'Exchange' && (
            <ExchangeView
              selectedServer={selectedServer}
              allServers={servers}
              onSelectServer={setSelectedServerId}
              candles={SQUAD_CANDLES}
              asks={ORDER_BOOK_ASKS}
              bids={ORDER_BOOK_BIDS}
              trades={trades}
              credBalance={exchangeCredBalance}
              onPlaceOrder={handlePlaceOrder}
              watchlist={watchlist}
              onToggleWatchlist={handleToggleWatchlist}
              joinedServers={joinedServers}
              onToggleJoinServer={handleToggleJoinServer}
              onSelectTab={setActiveTab}
            />
          )}

          {activeTab === 'Wallet' && (
            <WalletView
              credBalance={homeCredBalance}
              inrBalance={inrBalance}
              servers={servers}
              activities={activities}
              onSelectTab={setActiveTab}
              onSelectServerForTrade={handleSelectServerForTrade}
              onOpenWithdrawModal={() => setActiveModal('withdraw')}
              onOpenVideoModal={() => setActiveModal('video')}
              onOpenAdModal={() => setActiveModal('ad')}
            />
          )}

          {activeTab === 'Leaderboard' && (
            <LeaderboardView
              traders={INITIAL_TRADER_LEADERBOARD}
              servers={INITIAL_SERVER_LEADERBOARD}
              onSelectServerForTrade={(ticker) => {
                const s = allCombinedServers.find((srv) => srv.id === ticker || srv.ticker.toLowerCase() === `$${ticker}`.toLowerCase());
                if (s) setSelectedServerId(s.id);
                setActiveTab('Exchange');
              }}
              onOpenBoostModal={(ticker) => {
                const s = allCombinedServers.find((srv) => srv.id === ticker || srv.ticker.toLowerCase() === `$${ticker}`.toLowerCase());
                if (s) setSelectedServerId(s.id);
                setActiveModal('boost');
              }}
              onSelectTab={setActiveTab}
            />
          )}

          {activeTab === 'Portfolio' && (
            <PortfolioView
              servers={servers}
              credBalance={homeCredBalance}
              inrBalance={inrBalance}
              onSelectTab={setActiveTab}
              onSelectServerForTrade={handleSelectServerForTrade}
              onOpenWithdrawModal={() => setActiveModal('withdraw')}
              onOpenBoostModal={() => setActiveModal('boost')}
            />
          )}

          {activeTab === 'Settings' && (
            <SettingsView
              settings={settings}
              onUpdateSettings={(newVals) => setSettings((prev) => ({ ...prev, ...newVals }))}
              user={user}
              onOpenDiscordLogin={() => setActiveTab('Login')}
              onTriggerToast={showToast}
            />
          )}

          {activeTab === 'Login' && (
            <DiscordLoginView
              user={user}
              onLoginSuccess={(newVals) => {
                setUser((prev) => ({ ...prev, ...newVals }));
                showToast(`Logged in with Discord as ${newVals.name || 'Ayush'}!`);
              }}
              onBackToApp={() => setActiveTab('Dashboard')}
            />
          )}
        </motion.div>
      </AnimatePresence>

      {/* Global Interactive Modals */}
      <ActionModals
        activeModal={activeModal}
        onClose={() => setActiveModal(null)}
        servers={servers}
        credBalance={homeCredBalance}
        inrBalance={inrBalance}
        onCompleteBoost={handleCompleteBoost}
        onCompleteVideo={handleCompleteVideo}
        onCompleteWithdraw={handleCompleteWithdraw}
        onCompleteAd={handleCompleteAd}
      />

      {/* Subtle Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#18181B] text-white text-[12.5px] font-medium px-4 py-2.5 rounded-xl shadow-lg border border-[#27272A] flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#10B981]" />
          <span>{toastMsg}</span>
        </div>
      )}
    </div>
  );
}

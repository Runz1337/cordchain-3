import React, { useState } from 'react';
import {
  Plus,
  TrendingUp,
  SlidersHorizontal,
  Smile,
  Ruler,
  Search,
  CircleDot,
  Sparkles,
  Type,
  PenTool,
  GitCommitHorizontal,
} from 'lucide-react';
import { CandlePoint, ServerAsset } from '../types';

interface CandlestickChartProps {
  server: ServerAsset;
  candles: CandlePoint[];
}

export const CandlestickChart: React.FC<CandlestickChartProps> = ({ server, candles }) => {
  const [activeTab, setActiveTab] = useState<'Chart' | 'Order Book' | 'Trades' | 'Info'>('Chart');
  const [timeframe, setTimeframe] = useState<'1m' | '5m' | '15m' | '1h' | '4h' | '1D'>('1h');
  const [chartType, setChartType] = useState<'candles' | 'line'>('candles');
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const [activeTool, setActiveTool] = useState<number>(0);
  const [showMA, setShowMA] = useState<boolean>(false);

  const priceRatio = server.priceUsd / 86.75;

  const scaledCandles = candles.map((c) => ({
    ...c,
    open: +(c.open * priceRatio).toFixed(2),
    high: +(c.high * priceRatio).toFixed(2),
    low: +(c.low * priceRatio).toFixed(2),
    close: +(c.close * priceRatio).toFixed(2),
  }));

  const currentCandle =
    hoveredIdx !== null ? scaledCandles[hoveredIdx] : scaledCandles[scaledCandles.length - 1];

  const minPrice = Math.floor(48 * priceRatio);
  const maxPrice = Math.ceil(103 * priceRatio);
  const priceSpan = maxPrice - minPrice;

  const svgWidth = 650;
  const svgHeight = 310;
  const chartTop = 18;
  const chartBottom = 236;
  const chartHeight = chartBottom - chartTop;
  const volTop = 242;
  const volBottom = 285;
  const volHeight = volBottom - volTop;
  const leftPad = 10;
  const rightPad = 52;
  const plotWidth = svgWidth - leftPad - rightPad;

  const priceToY = (p: number) => {
    return chartTop + ((maxPrice - p) / priceSpan) * chartHeight;
  };

  const yTicks = [100, 90, 80, 70, 60, 50].map((v) => +(v * priceRatio).toFixed(2));
  const lastClose = scaledCandles[scaledCandles.length - 1].close;
  const lastCloseY = priceToY(lastClose);

  const candleSpacing = plotWidth / scaledCandles.length;
  const candleWidth = Math.max(3.5, candleSpacing * 0.56);

  const drawingTools = [
    { icon: <Plus className="w-4 h-4" />, label: 'Crosshair' },
    { icon: <GitCommitHorizontal className="w-4 h-4 -rotate-45" />, label: 'Trend Line' },
    { icon: <SlidersHorizontal className="w-4 h-4" />, label: 'Fib Retracement' },
    { icon: <PenTool className="w-3.5 h-3.5" />, label: 'Brush' },
    { icon: <Type className="w-3.5 h-3.5" />, label: 'Text' },
    { icon: <Sparkles className="w-3.5 h-3.5" />, label: 'Pattern' },
    { icon: <Ruler className="w-3.5 h-3.5" />, label: 'Measure' },
    { icon: <Smile className="w-3.5 h-3.5" />, label: 'Emoji' },
    { icon: <Search className="w-3.5 h-3.5" />, label: 'Zoom' },
    { icon: <CircleDot className="w-3.5 h-3.5" />, label: 'Magnet' },
  ];

  const changeVal = +(currentCandle.close - currentCandle.open).toFixed(2);
  const changePct = +((changeVal / currentCandle.open) * 100).toFixed(2);

  return (
    <div className="bg-white border border-[#EAE9E4] rounded-2xl p-4 flex flex-col justify-between h-full select-none">
      <div>
        <div className="flex items-center gap-6 border-b border-[#EAE9E4] px-1">
          {(['Chart', 'Order Book', 'Trades', 'Info'] as const).map((tab) => {
            const isActive = activeTab === tab;
            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`pb-2.5 text-[12.5px] font-medium relative transition-colors cursor-pointer ${
                  isActive ? 'text-[#18181B] font-semibold' : 'text-[#71717A] hover:text-[#18181B]'
                }`}
              >
                {tab}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#18181B] rounded-full" />
                )}
              </button>
            );
          })}
        </div>

        <div className="flex items-center justify-between py-2.5 px-1 border-b border-[#F3F2EE]">
          <div className="flex items-center gap-1.5">
            {(['1m', '5m', '15m', '1h', '4h', '1D'] as const).map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={`px-2.5 py-1 rounded-md text-[11.5px] font-medium transition-colors cursor-pointer ${
                  timeframe === tf
                    ? 'bg-[#EFECE6] text-[#18181B] font-semibold'
                    : 'text-[#71717A] hover:text-[#18181B] hover:bg-[#F7F6F3]'
                }`}
              >
                {tf}
              </button>
            ))}

            <span className="h-4 w-[1px] bg-[#EAE9E4] mx-2" />

            <button
              onClick={() => setChartType('candles')}
              title="Candlestick Chart"
              className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                chartType === 'candles'
                  ? 'bg-[#EFECE6] text-[#18181B]'
                  : 'text-[#71717A] hover:text-[#18181B]'
              }`}
            >
              <svg viewBox="0 0 16 16" className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="1.5">
                <line x1="4.5" y1="2" x2="4.5" y2="14" />
                <rect x="3" y="5" width="3" height="6" fill="currentColor" />
                <line x1="11.5" y1="3" x2="11.5" y2="13" />
                <rect x="10" y="6" width="3" height="4" fill="white" />
              </svg>
            </button>

            <button
              onClick={() => setChartType('line')}
              title="Line Chart"
              className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                chartType === 'line'
                  ? 'bg-[#EFECE6] text-[#18181B]'
                  : 'text-[#71717A] hover:text-[#18181B]'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => setShowMA(!showMA)}
              className={`ml-1 px-2.5 py-1 rounded-md text-[11.5px] font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                showMA
                  ? 'bg-[#EFECE6] text-[#18181B]'
                  : 'text-[#52525B] hover:text-[#18181B] hover:bg-[#F7F6F3]'
              }`}
            >
              <svg viewBox="0 0 16 16" className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M2 12 C5 12, 6 4, 9 4 C12 4, 13 9, 14 9" />
              </svg>
              <span>Indicators</span>
            </button>
          </div>
        </div>
      </div>

      <div className="flex flex-1 pt-2 min-h-[315px]">
        <div className="w-8 pr-2 border-r border-[#F3F2EE] flex flex-col items-center justify-between py-1 text-[#71717A]">
          {drawingTools.map((tool, index) => (
            <button
              key={tool.label}
              onClick={() => setActiveTool(index)}
              title={tool.label}
              className={`p-1 rounded-md transition-colors cursor-pointer ${
                activeTool === index
                  ? 'text-[#3B82F6] bg-[#EFF6FF]'
                  : 'hover:text-[#18181B] hover:bg-[#F7F6F3]'
              }`}
            >
              {tool.icon}
            </button>
          ))}
        </div>

        <div className="flex-1 relative pl-2">
          <div className="absolute top-1 left-4 z-10 pointer-events-none">
            <p className="text-[12.5px] font-medium text-[#3F3F46]">
              {server.ticker} · {timeframe} · CORDCHAIN
            </p>
            <div className="flex items-center gap-2 text-[11px] font-mono tabular-nums mt-0.5">
              <span className="text-[#71717A]">
                O <span className="text-[#10B981]">{currentCandle.open.toFixed(2)}</span>
              </span>
              <span className="text-[#71717A]">
                H <span className="text-[#10B981]">{currentCandle.high.toFixed(2)}</span>
              </span>
              <span className="text-[#71717A]">
                L <span className="text-[#10B981]">{currentCandle.low.toFixed(2)}</span>
              </span>
              <span className="text-[#71717A]">
                C <span className="text-[#10B981]">{currentCandle.close.toFixed(2)}</span>
              </span>
              <span className={changeVal >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'}>
                {changeVal >= 0 ? '+' : ''}
                {changeVal.toFixed(2)} ({changePct >= 0 ? '+' : ''}
                {changePct.toFixed(2)}%)
              </span>
            </div>
          </div>

          <svg
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            className="w-full h-full overflow-visible"
            onMouseLeave={() => setHoveredIdx(null)}
          >
            {yTicks.map((tick) => {
              const y = priceToY(tick);
              return (
                <g key={tick}>
                  <line
                    x1={leftPad}
                    y1={y}
                    x2={svgWidth - rightPad}
                    y2={y}
                    stroke="#F3F2EE"
                    strokeWidth="1"
                  />
                  <text
                    x={svgWidth - rightPad + 8}
                    y={y + 3.5}
                    className="fill-[#A1A1AA] text-[9.5px] font-mono tabular-nums"
                  >
                    {tick.toFixed(2)}
                  </text>
                </g>
              );
            })}

            {scaledCandles.map((c, i) => {
              if (!c.dateLabel) return null;
              const x = leftPad + i * candleSpacing + candleSpacing / 2;
              return (
                <g key={c.time}>
                  <line
                    x1={x}
                    y1={chartTop}
                    x2={x}
                    y2={volBottom}
                    stroke="#F6F5F2"
                    strokeWidth="1"
                  />
                  <text
                    x={x}
                    y={svgHeight - 6}
                    textAnchor="middle"
                    className="fill-[#A1A1AA] text-[9.5px] font-sans"
                  >
                    {c.dateLabel}
                  </text>
                </g>
              );
            })}

            {showMA && (
              <path
                d={scaledCandles
                  .map((c, i) => {
                    const slice = scaledCandles.slice(Math.max(0, i - 5), i + 1);
                    const avg = slice.reduce((acc, item) => acc + item.close, 0) / slice.length;
                    const x = leftPad + i * candleSpacing + candleSpacing / 2;
                    const y = priceToY(avg);
                    return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                  })
                  .join(' ')}
                fill="none"
                stroke="#3B82F6"
                strokeWidth="1.5"
                strokeDasharray="2 2"
              />
            )}

            {chartType === 'line' ? (
              <path
                d={scaledCandles
                  .map((c, i) => {
                    const x = leftPad + i * candleSpacing + candleSpacing / 2;
                    const y = priceToY(c.close);
                    return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                  })
                  .join(' ')}
                fill="none"
                stroke="#10B981"
                strokeWidth="2"
              />
            ) : (
              scaledCandles.map((c, i) => {
                const xCenter = leftPad + i * candleSpacing + candleSpacing / 2;
                const isBull = c.close >= c.open;
                const color = isBull ? '#10B981' : '#EF4444';
                const volColor = isBull ? 'rgba(16, 185, 129, 0.25)' : 'rgba(239, 68, 68, 0.25)';

                const highY = priceToY(c.high);
                const lowY = priceToY(c.low);
                const bodyTop = priceToY(Math.max(c.open, c.close));
                const bodyBottom = priceToY(Math.min(c.open, c.close));
                const bodyHeight = Math.max(2, bodyBottom - bodyTop);

                const vBarHeight = (c.volume / 100) * volHeight;
                const vBarY = volBottom - vBarHeight;

                return (
                  <g
                    key={c.time}
                    onMouseEnter={() => setHoveredIdx(i)}
                    className="cursor-crosshair"
                  >
                    <rect
                      x={xCenter - candleSpacing / 2}
                      y={chartTop}
                      width={candleSpacing}
                      height={volBottom - chartTop}
                      fill="transparent"
                    />
                    <line
                      x1={xCenter}
                      y1={highY}
                      x2={xCenter}
                      y2={lowY}
                      stroke={color}
                      strokeWidth="1.2"
                    />
                    <rect
                      x={xCenter - candleWidth / 2}
                      y={bodyTop}
                      width={candleWidth}
                      height={bodyHeight}
                      rx="0.8"
                      fill={color}
                    />
                    <rect
                      x={xCenter - candleWidth / 2}
                      y={vBarY}
                      width={candleWidth}
                      height={vBarHeight}
                      rx="0.5"
                      fill={volColor}
                    />
                  </g>
                );
              })
            )}

            {hoveredIdx !== null && (
              <line
                x1={leftPad + hoveredIdx * candleSpacing + candleSpacing / 2}
                y1={chartTop}
                x2={leftPad + hoveredIdx * candleSpacing + candleSpacing / 2}
                y2={volBottom}
                stroke="#A1A1AA"
                strokeWidth="0.8"
                strokeDasharray="3 3"
                pointerEvents="none"
              />
            )}

            <line
              x1={leftPad}
              y1={lastCloseY}
              x2={svgWidth - rightPad}
              y2={lastCloseY}
              stroke="#10B981"
              strokeWidth="0.9"
              strokeDasharray="3 3"
            />
            <g transform={`translate(${svgWidth - rightPad + 2}, ${lastCloseY - 9})`}>
              <rect width="42" height="18" rx="4" fill="#159966" />
              <text
                x="21"
                y="12.5"
                textAnchor="middle"
                className="fill-white text-[9.5px] font-mono font-semibold tabular-nums"
              >
                {lastClose.toFixed(2)}
              </text>
            </g>
          </svg>

          <div className="absolute bottom-7 left-5 w-6 h-6 rounded-full bg-white border border-[#EAE9E4] shadow-2xs flex items-center justify-center text-[8px] font-black tracking-tighter text-[#18181B]">
            TV
          </div>
        </div>
      </div>
    </div>
  );
};

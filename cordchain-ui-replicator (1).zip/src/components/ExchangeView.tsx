import React, { useState } from 'react';
import {
  Store,
  Star,
  Wallet,
  Trophy,
  ArrowRight,
  ArrowUpRight,
  ArrowDownRight,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  RefreshCw,
  Search,
} from 'lucide-react';
import {
  ServerAsset,
  ExchangeSideNav,
  OrderBookRow,
  TradeRecord,
  CandlePoint,
  MainTab,
} from '../types';
import { ServerIcon, DiscordLogo } from './Icons';
import { CandlestickChart } from './CandlestickChart';
import { TOP_LEAGUES } from '../data/mockData';

interface ExchangeViewProps {
  selectedServer: ServerAsset;
  allServers: ServerAsset[];
  onSelectServer: (serverId: string) => void;
  candles: CandlePoint[];
  asks: OrderBookRow[];
  bids: OrderBookRow[];
  trades: TradeRecord[];
  credBalance: number;
  onPlaceOrder: (side: 'buy' | 'sell', amount: number, priceUsd: number) => void;
  watchlist: string[];
  onToggleWatchlist: (serverId: string) => void;
  joinedServers: string[];
  onToggleJoinServer: (serverId: string) => void;
  onSelectTab: (tab: MainTab) => void;
}

export const ExchangeView: React.FC<ExchangeViewProps> = ({
  selectedServer,
  allServers,
  onSelectServer,
  candles,
  asks,
  bids,
  trades,
  credBalance,
  onPlaceOrder,
  watchlist,
  onToggleWatchlist,
  joinedServers,
  onToggleJoinServer,
  onSelectTab,
}) => {
  const [sideNav, setSideNav] = useState<ExchangeSideNav>('Market');
  const [orderSide, setOrderSide] = useState<'buy' | 'sell'>('buy');
  const [orderType, setOrderType] = useState<'Market' | 'Limit' | 'Stop-Limit'>('Market');
  const [amountInput, setAmountInput] = useState<string>('0');
  const [perfRange, setPerfRange] = useState<'1D' | '1W' | '1M' | '3M' | '1Y'>('1D');
  const [precision, setPrecision] = useState<'0.01' | '0.1' | '1.0'>('0.01');
  const [selectedLeagueFilter, setSelectedLeagueFilter] = useState<string | null>(null);

  const numericAmount = parseFloat(amountInput) || 0;
  const totalUsd = +(numericAmount * selectedServer.priceUsd).toFixed(2);
  const priceRatio = selectedServer.priceUsd / 86.75;

  const isStarred = watchlist.includes(selectedServer.id);
  const isJoined = joinedServers.includes(selectedServer.id);

  const relatedOrder = ['code', 'valo', 'gaming', 'ai'];
  const relatedServers = relatedOrder
    .map((id) => allServers.find((s) => s.id === id))
    .filter((s): s is ServerAsset => Boolean(s));

  const relatedOverrides: Record<string, { change: number }> = {
    code: { change: 9.8 },
    valo: { change: 6.1 },
    gaming: { change: 5.4 },
    ai: { change: 8.7 },
  };

  const handlePercentageClick = (pct: number) => {
    if (orderSide === 'buy') {
      const maxShares = Math.floor(((credBalance * (pct / 100)) / selectedServer.priceUsd) * 10) / 10;
      setAmountInput(String(Math.max(1, Math.round(maxShares))));
    } else {
      const owned = selectedServer.holdings || 24320;
      setAmountInput(String(Math.floor(owned * (pct / 100))));
    }
  };

  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const qty = numericAmount > 0 ? numericAmount : 10;
    onPlaceOrder(orderSide, qty, selectedServer.priceUsd);
    setAmountInput('0');
  };

  const handleSideNavClick = (nav: ExchangeSideNav) => {
    setSideNav(nav);
    if (nav === 'Leaderboard') {
      onSelectTab('Leaderboard');
    } else if (nav === 'My Portfolio') {
      onSelectTab('Portfolio');
    }
  };

  const renderLeagueIcon = (id: string) => {
    switch (id) {
      case 'Titan':
        return (
          <div className="w-8 h-8 rounded-full bg-[#EFECE6] flex items-center justify-center text-[#18181B] shrink-0">
            <Trophy className="w-4 h-4" />
          </div>
        );
      case 'Arena':
        return (
          <div className="w-8 h-8 rounded-full bg-[#EFECE6] flex items-center justify-center text-[#18181B] shrink-0">
            <DiscordLogo className="w-4 h-4" />
          </div>
        );
      case 'Club':
        return (
          <div className="w-8 h-8 rounded-full bg-[#EFECE6] flex items-center justify-center text-[#4F46E5] shrink-0">
            <div className="w-4 h-4 rounded bg-[#4F46E5] text-white text-[9px] font-bold flex items-center justify-center">
              C
            </div>
          </div>
        );
      default:
        return (
          <div className="w-8 h-8 rounded-full bg-[#EFECE6] flex items-center justify-center text-[#3B82F6] shrink-0">
            <DiscordLogo className="w-4 h-4" />
          </div>
        );
    }
  };

  const holdingsCount = selectedServer.holdings ?? 24320;
  const avgPrice = selectedServer.avgBuyPriceUsd ?? 72.41;
  const pnlPct = +(((selectedServer.priceUsd - avgPrice) / avgPrice) * 100).toFixed(1);

  return (
    <div className="max-w-[1440px] mx-auto px-5 py-5 flex gap-4 items-start">
      {/* LEFT SIDEBAR */}
      <aside className="w-[205px] shrink-0 flex flex-col justify-between min-h-[calc(100vh-104px)] select-none">
        <div>
          {/* Exchange Title Block */}
          <div className="flex items-start gap-2.5 px-2 mb-4">
            <div className="w-7 h-7 rounded-lg bg-[#EFECE6] flex items-center justify-center text-[#18181B] shrink-0 mt-0.5">
              <Store className="w-4 h-4" strokeWidth={1.9} />
            </div>
            <div>
              <h2 className="text-[13.5px] font-semibold text-[#18181B] leading-tight">Exchange</h2>
              <p className="text-[11px] text-[#71717A] mt-0.5">Trade Discord server stocks</p>
            </div>
          </div>

          {/* Exchange Sidebar Navigation */}
          <nav className="space-y-1">
            {[
              {
                id: 'Market' as ExchangeSideNav,
                label: 'Market',
                icon: (
                  <svg viewBox="0 0 16 16" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <line x1="4.5" y1="2" x2="4.5" y2="14" />
                    <rect x="3" y="5" width="3" height="6" fill="currentColor" />
                    <line x1="11.5" y1="3" x2="11.5" y2="13" />
                    <rect x="10" y="6" width="3" height="4" />
                  </svg>
                ),
              },
              { id: 'Watchlist' as ExchangeSideNav, label: 'Watchlist', icon: <Star className="w-4 h-4" /> },
              { id: 'My Portfolio' as ExchangeSideNav, label: 'My Portfolio', icon: <Wallet className="w-4 h-4" /> },
              { id: 'Leaderboard' as ExchangeSideNav, label: 'Leaderboard', icon: <Trophy className="w-4 h-4" /> },
            ].map((item) => {
              const isActive = sideNav === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleSideNavClick(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-[13px] transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-[#EFECE6] text-[#18181B] font-semibold'
                      : 'text-[#52525B] hover:bg-[#EFECE6]/50 hover:text-[#18181B] font-medium'
                  }`}
                >
                  <span>{item.icon}</span>
                  <span className="whitespace-nowrap">{item.label}</span>
                </button>
              );
            })}
          </nav>

          <hr className="my-5 border-[#EAE9E4]" />

          {/* Top Leagues */}
          <div>
            <div className="flex items-center justify-between px-2 mb-3">
              <span className="text-[12px] font-semibold text-[#18181B]">Top Leagues</span>
              <button
                onClick={() => setSelectedLeagueFilter(null)}
                className="text-[11px] text-[#71717A] hover:text-[#18181B] inline-flex items-center gap-1 cursor-pointer"
              >
                <span>View all</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-2.5">
              {TOP_LEAGUES.map((league) => {
                const isSelected = selectedLeagueFilter === league.id;
                return (
                  <button
                    key={league.id}
                    onClick={() => {
                      setSelectedLeagueFilter(isSelected ? null : league.id);
                      const matching = allServers.find((s) => s.league === league.id);
                      if (matching) onSelectServer(matching.id);
                    }}
                    className={`w-full flex items-center justify-between px-2 py-1.5 rounded-xl transition-colors text-left cursor-pointer ${
                      isSelected ? 'bg-[#EFECE6]' : 'hover:bg-[#EFECE6]/50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      {renderLeagueIcon(league.id)}
                      <div>
                        <p className="text-[12.5px] font-semibold text-[#18181B] leading-tight">
                          {league.name}
                        </p>
                        <p className="text-[10.5px] text-[#71717A] mt-0.5">{league.subtitle}</p>
                      </div>
                    </div>
                    <span className="text-[11.5px] text-[#71717A] tabular-nums">{league.count}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Bottom Promo Card */}
        <div className="mt-6 bg-white border border-[#EAE9E4] rounded-2xl p-4">
          <p className="text-[13px] font-semibold text-[#18181B]">Trade. Grow. Earn.</p>
          <p className="text-[11px] text-[#71717A] leading-relaxed mt-1 mb-3">
            Every server you trade helps your community grow.
          </p>
          <svg viewBox="0 0 160 54" className="w-full h-12 overflow-visible">
            {[20, 42, 64, 86, 108, 130, 148].map((x, idx) => (
              <line
                key={x}
                x1={x}
                y1={42 - idx * 4}
                x2={x}
                y2={50}
                stroke="#EAE9E4"
                strokeWidth="1"
              />
            ))}
            <path
              d="M10 44 L36 33 L58 37 L88 22 L112 26 L146 8"
              fill="none"
              stroke="#159966"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M140 7 L147 8 L146 15"
              fill="none"
              stroke="#159966"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </aside>

      {/* Watchlist View Mode if Watchlist is selected */}
      {sideNav === 'Watchlist' ? (
        <main className="flex-1 min-w-0 bg-white border border-[#EAE9E4] rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#EAE9E4]">
            <div>
              <h2 className="text-[18px] font-bold text-[#18181B]">Your Watchlist ({watchlist.length})</h2>
              <p className="text-[12px] text-[#71717A]">Quickly monitor and trade your pinned Discord servers.</p>
            </div>
            <button
              onClick={() => setSideNav('Market')}
              className="px-3.5 py-1.5 rounded-xl border border-[#EAE9E4] hover:bg-[#F8F7F4] text-[12px] font-medium text-[#18181B]"
            >
              Back to Full Market
            </button>
          </div>

          <div className="divide-y divide-[#F4F3EE]">
            {allServers
              .filter((s) => watchlist.includes(s.id))
              .map((srv) => (
                <div key={srv.id} className="py-4 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => onToggleWatchlist(srv.id)}
                      className="text-[#CA8A04] hover:opacity-80"
                    >
                      <Star className="w-4 h-4 fill-current" />
                    </button>
                    <ServerIcon id={srv.id} variant="table" />
                    <div>
                      <p className="font-semibold text-[#18181B] text-[13.5px]">{srv.ticker}</p>
                      <p className="text-[11.5px] text-[#71717A]">{srv.name}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="text-right font-mono">
                      <p className="text-[14px] font-bold text-[#18181B]">${srv.priceUsd.toFixed(2)}</p>
                      <p
                        className={`text-[11.5px] font-medium ${
                          srv.change24h >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'
                        }`}
                      >
                        {srv.change24h >= 0 ? '+' : ''}{srv.change24h.toFixed(1)}%
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        onSelectServer(srv.id);
                        setSideNav('Market');
                      }}
                      className="px-4 py-2 rounded-xl bg-[#18181B] hover:bg-[#27272A] text-white text-[12px] font-semibold"
                    >
                      Trade
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </main>
      ) : (
        /* CENTER MAIN TRADING WORKSPACE */
        <main className="flex-1 min-w-0 space-y-4">
          {/* Server Header Card */}
          <section className="bg-white border border-[#EAE9E4] rounded-2xl p-5">
            <div className="flex flex-wrap items-start justify-between gap-4">
              {/* Left Server Identity */}
              <div className="flex items-start gap-3.5">
                <ServerIcon id={selectedServer.id} variant="header" />
                <div>
                  <h1 className="text-[21px] font-bold text-[#18181B] leading-tight">
                    {selectedServer.ticker}
                  </h1>
                  <p className="text-[12.5px] text-[#71717A] mt-0.5">{selectedServer.name}</p>
                  <div className="flex items-center gap-1.5 mt-2">
                    <span className="px-2 py-0.5 rounded-md bg-[#F4EFE6] text-[#8C734B] text-[10.5px] font-semibold">
                      {selectedServer.league}
                    </span>
                    <span className="px-2 py-0.5 rounded-md border border-[#EAE9E4] text-[#52525B] text-[10.5px] font-medium">
                      Rank #{selectedServer.rank}
                    </span>
                    <span className="px-2 py-0.5 rounded-md border border-[#EAE9E4] text-[#52525B] text-[10.5px] font-medium">
                      {selectedServer.members} members
                    </span>
                  </div>
                </div>
              </div>

              {/* Right Stats + Actions */}
              <div className="flex items-center gap-6">
                <div className="flex items-center divide-x divide-[#EAE9E4] text-[12px]">
                  <div className="px-4">
                    <p className="text-[11px] text-[#71717A] mb-1">24h High</p>
                    <p className="font-semibold text-[#18181B] tabular-nums text-[13.5px]">
                      ${selectedServer.high24hUsd.toFixed(2)}
                    </p>
                  </div>
                  <div className="px-4">
                    <p className="text-[11px] text-[#71717A] mb-1">24h Low</p>
                    <p className="font-semibold text-[#18181B] tabular-nums text-[13.5px]">
                      ${selectedServer.low24hUsd.toFixed(2)}
                    </p>
                  </div>
                  <div className="px-4">
                    <p className="text-[11px] text-[#71717A] mb-1">Volume (24h)</p>
                    <p className="font-semibold text-[#18181B] tabular-nums text-[13.5px]">
                      {selectedServer.volume24h}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onToggleJoinServer(selectedServer.id)}
                    className={`px-3.5 py-2 rounded-xl border text-[12px] font-medium inline-flex items-center gap-2 transition-colors cursor-pointer ${
                      isJoined
                        ? 'bg-[#18181B] text-white border-[#18181B]'
                        : 'bg-white hover:bg-[#F7F6F3] text-[#18181B] border-[#E4E3DE]'
                    }`}
                  >
                    <DiscordLogo className="w-3.5 h-3.5" />
                    <span>{isJoined ? 'Joined Server' : 'Join Server'}</span>
                    {!isJoined && <ArrowRight className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    onClick={() => onToggleWatchlist(selectedServer.id)}
                    aria-label="Toggle Watchlist"
                    className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                      isStarred
                        ? 'bg-[#FEF9C3] border-[#FDE047] text-[#CA8A04]'
                        : 'bg-white hover:bg-[#F7F6F3] border-[#E4E3DE] text-[#52525B]'
                    }`}
                  >
                    <Star className={`w-4 h-4 ${isStarred ? 'fill-current' : ''}`} />
                  </button>
                </div>
              </div>
            </div>

            {/* Big Price Readout */}
            <div className="mt-4 flex items-baseline gap-3">
              <span className="text-[28px] font-bold text-[#18181B] tabular-nums tracking-tight">
                ${selectedServer.priceUsd.toFixed(2)}
              </span>
              <span
                className={`text-[13.5px] font-semibold inline-flex items-center gap-1 tabular-nums ${
                  selectedServer.change24h >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'
                }`}
              >
                {selectedServer.change24h >= 0 ? (
                  <ArrowUpRight className="w-4 h-4" />
                ) : (
                  <ArrowDownRight className="w-4 h-4" />
                )}
                <span>
                  {selectedServer.change24h >= 0 ? '+' : ''}
                  {selectedServer.id === 'squad' ? '12.4%' : `${selectedServer.change24h.toFixed(1)}%`}
                </span>
                <span className="text-[#71717A] font-normal">(24h)</span>
              </span>
            </div>
          </section>

          {/* Middle Split: Candlestick Chart (8 cols) + Order Book (4 cols) */}
          <div className="grid grid-cols-12 gap-4 items-stretch">
            <div className="col-span-12 xl:col-span-8">
              <CandlestickChart server={selectedServer} candles={candles} />
            </div>

            {/* Order Book Card */}
            <div className="col-span-12 xl:col-span-4 bg-white border border-[#EAE9E4] rounded-2xl p-4 flex flex-col justify-between select-none">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-[14px] font-semibold text-[#18181B]">Order Book</h2>
                  <button
                    onClick={() =>
                      setPrecision((p) => (p === '0.01' ? '0.1' : p === '0.1' ? '1.0' : '0.01'))
                    }
                    className="px-2.5 py-1 rounded-lg border border-[#EAE9E4] text-[11px] font-mono text-[#52525B] inline-flex items-center gap-1.5 hover:bg-[#F7F6F3] cursor-pointer"
                  >
                    <span>{precision}</span>
                    <ChevronDown className="w-3 h-3" />
                  </button>
                </div>

                <div className="grid grid-cols-3 text-[11px] text-[#A1A1AA] pb-2 border-b border-[#F3F2EE]">
                  <span>Price (USD)</span>
                  <span className="text-right">Amount</span>
                  <span className="text-right">Total</span>
                </div>

                {/* Asks (Red) */}
                <div className="divide-y divide-[#FAF9F6] my-1">
                  {asks.map((ask, idx) => {
                    const scaledPrice = +(ask.price * priceRatio).toFixed(2);
                    return (
                      <div
                        key={idx}
                        onClick={() => setAmountInput(String(ask.amount))}
                        className="grid grid-cols-3 py-1.5 text-[11.5px] font-mono tabular-nums relative overflow-hidden cursor-pointer hover:bg-[#FDF2F2]/60 rounded"
                      >
                        <div
                          className="absolute right-0 top-0.5 bottom-0.5 bg-[#FEE2E2]/55 pointer-events-none"
                          style={{ width: `${ask.depthPercent}%` }}
                        />
                        <span className="text-[#EF4444] font-medium relative z-10">
                          {scaledPrice.toFixed(2)}
                        </span>
                        <span className="text-right text-[#3F3F46] relative z-10">
                          {ask.amount.toLocaleString()}
                        </span>
                        <span className="text-right text-[#3F3F46] relative z-10 pr-1">
                          {ask.total}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* Spread / Current Price */}
                <div className="py-2 my-1 border-y border-[#F3F2EE] flex items-center gap-1.5">
                  <span className="text-[17px] font-bold text-[#10B981] font-mono tabular-nums">
                    {selectedServer.priceUsd.toFixed(2)}
                  </span>
                  <span className="text-[#10B981] text-[14px] font-bold">↑</span>
                </div>

                {/* Bids (Green) */}
                <div className="divide-y divide-[#FAF9F6] my-1">
                  {bids.map((bid, idx) => {
                    const scaledPrice = +(bid.price * priceRatio).toFixed(2);
                    return (
                      <div
                        key={idx}
                        onClick={() => setAmountInput(String(bid.amount))}
                        className="grid grid-cols-3 py-1.5 text-[11.5px] font-mono tabular-nums relative overflow-hidden cursor-pointer hover:bg-[#ECFDF5]/60 rounded"
                      >
                        <div
                          className="absolute right-0 top-0.5 bottom-0.5 bg-[#DCFCE7]/60 pointer-events-none"
                          style={{ width: `${bid.depthPercent}%` }}
                        />
                        <span className="text-[#10B981] font-medium relative z-10">
                          {scaledPrice.toFixed(2)}
                        </span>
                        <span className="text-right text-[#3F3F46] relative z-10">
                          {bid.amount.toLocaleString()}
                        </span>
                        <span className="text-right text-[#3F3F46] relative z-10 pr-1">
                          {bid.total}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Bottom Bid/Ask Depth Visualization (38% / 62%) */}
              <div className="pt-2">
                <svg viewBox="0 0 220 34" className="w-full h-8 overflow-visible">
                  <path
                    d="M0 6 L28 6 L42 15 L68 15 L82 26 L95 32 L0 32 Z"
                    fill="rgba(239, 68, 68, 0.12)"
                  />
                  <path
                    d="M0 6 L28 6 L42 15 L68 15 L82 26 L95 32"
                    fill="none"
                    stroke="#EF4444"
                    strokeWidth="1"
                    strokeOpacity="0.5"
                  />
                  <path
                    d="M122 32 L138 24 L164 20 L185 12 L220 4 L220 32 Z"
                    fill="rgba(16, 185, 129, 0.12)"
                  />
                  <path
                    d="M122 32 L138 24 L164 20 L185 12 L220 4"
                    fill="none"
                    stroke="#10B981"
                    strokeWidth="1"
                    strokeOpacity="0.5"
                  />
                </svg>
                <div className="flex items-center justify-between text-[10.5px] font-mono font-semibold mt-0.5">
                  <span className="text-[#EF4444]">38%</span>
                  <div className="flex-1 mx-2 h-1 rounded-full bg-[#DCFCE7] overflow-hidden flex">
                    <div className="w-[38%] bg-[#FCA5A5]" />
                    <div className="w-[62%] bg-[#86EFAC]" />
                  </div>
                  <span className="text-[#10B981]">62%</span>
                </div>
              </div>
            </div>
          </div>

          {/* 3-Column Row */}
          <div className="grid grid-cols-12 gap-4 items-stretch">
            {/* Price Overview */}
            <div className="col-span-12 md:col-span-3 bg-white border border-[#EAE9E4] rounded-2xl p-5 flex flex-col justify-between">
              <div>
                <h3 className="text-[13.5px] font-semibold text-[#18181B] mb-2">Price Overview</h3>
                <div className="flex items-baseline gap-2 mb-4">
                  <span className="text-[22px] font-bold text-[#18181B] tabular-nums">
                    ${selectedServer.priceUsd.toFixed(2)}
                  </span>
                  <span className="text-[11.5px] font-semibold text-[#10B981] inline-flex items-center gap-0.5 tabular-nums">
                    <ArrowUpRight className="w-3 h-3" />+12.4% (24h)
                  </span>
                </div>
              </div>

              <div className="space-y-2.5 text-[12px]">
                <div className="flex items-center justify-between">
                  <span className="text-[#71717A]">24h High</span>
                  <span className="font-semibold text-[#18181B] tabular-nums">
                    ${selectedServer.high24hUsd.toFixed(2)}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#71717A]">24h Low</span>
                  <span className="font-semibold text-[#18181B] tabular-nums">
                    ${selectedServer.low24hUsd.toFixed(2)}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#71717A]">Volume</span>
                  <span className="font-semibold text-[#18181B] tabular-nums">
                    {selectedServer.volume24h}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#71717A]">Market Cap</span>
                  <span className="font-semibold text-[#18181B] tabular-nums">
                    {selectedServer.marketCapUsd}
                  </span>
                </div>
              </div>
            </div>

            {/* About $SQUAD */}
            <div className="col-span-12 md:col-span-4 bg-white border border-[#EAE9E4] rounded-2xl p-5 flex flex-col justify-between">
              <div>
                <h3 className="text-[13.5px] font-semibold text-[#18181B] mb-2">
                  About {selectedServer.ticker}
                </h3>
                <p className="text-[12px] text-[#71717A] leading-[1.55] mb-3.5">
                  {selectedServer.description}
                </p>
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {selectedServer.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2.5 py-1 rounded-full bg-[#F5F4F0] text-[#52525B] text-[11px] font-medium"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <button
                  onClick={() => onToggleJoinServer(selectedServer.id)}
                  className="px-3.5 py-2 rounded-xl border border-[#E4E3DE] hover:bg-[#F7F6F3] text-[12px] font-medium text-[#18181B] inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <span>Visit Server</span>
                  <ExternalLink className="w-3.5 h-3.5 text-[#71717A]" />
                </button>
              </div>
            </div>

            {/* 24h Performance */}
            <div className="col-span-12 md:col-span-5 bg-white border border-[#EAE9E4] rounded-2xl p-5 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-[13.5px] font-semibold text-[#18181B]">24h Performance</h3>
                <div className="flex items-center gap-1">
                  {(['1D', '1W', '1M', '3M', '1Y'] as const).map((r) => (
                    <button
                      key={r}
                      onClick={() => setPerfRange(r)}
                      className={`px-2 py-0.5 rounded text-[10.5px] font-medium transition-colors cursor-pointer ${
                        perfRange === r
                          ? 'bg-[#EFECE6] text-[#18181B] font-semibold'
                          : 'text-[#A1A1AA] hover:text-[#18181B]'
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>

              {/* Area Sparkline */}
              <div className="my-2">
                <svg viewBox="0 0 320 75" className="w-full h-16 overflow-visible">
                  <defs>
                    <linearGradient id="perfArea" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#10B981" stopOpacity="0.18" />
                      <stop offset="100%" stopColor="#10B981" stopOpacity="0.0" />
                    </linearGradient>
                  </defs>
                  <path
                    d="M0 58 L24 44 L44 49 L68 37 L92 42 L116 28 L138 34 L162 21 L184 26 L202 10 L202 72 L0 72 Z"
                    fill="url(#perfArea)"
                  />
                  <path
                    d="M0 58 L24 44 L44 49 L68 37 L92 42 L116 28 L138 34 L162 21 L184 26 L202 10"
                    fill="none"
                    stroke="#159966"
                    strokeWidth="1.6"
                  />
                  <path
                    d="M206 54 L228 47 L248 50 L272 39 L295 43 L320 30 L320 72 L206 72 Z"
                    fill="url(#perfArea)"
                  />
                  <path
                    d="M206 54 L228 47 L248 50 L272 39 L295 43 L320 30"
                    fill="none"
                    stroke="#159966"
                    strokeWidth="1.4"
                    strokeOpacity="0.7"
                  />
                </svg>
              </div>

              <div className="grid grid-cols-3 gap-2 pt-1">
                <div>
                  <p className="text-[14px] font-bold text-[#10B981] tabular-nums">+12.4%</p>
                  <p className="text-[10.5px] text-[#A1A1AA]">Price Change</p>
                </div>
                <div>
                  <p className="text-[14px] font-bold text-[#10B981] tabular-nums">+18.7%</p>
                  <p className="text-[10.5px] text-[#A1A1AA]">Volume Change</p>
                </div>
                <div>
                  <p className="text-[14px] font-bold text-[#10B981] tabular-nums">+6.2%</p>
                  <p className="text-[10.5px] text-[#A1A1AA]">Market Cap Change</p>
                </div>
              </div>
            </div>
          </div>

          {/* Related Servers Row */}
          <section className="bg-white border border-[#EAE9E4] rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3.5">
              <h3 className="text-[13.5px] font-semibold text-[#18181B]">Related Servers</h3>
              <button
                onClick={() => onSelectServer('ai')}
                className="text-[11.5px] text-[#71717A] hover:text-[#18181B] inline-flex items-center gap-1 cursor-pointer"
              >
                <span>View all</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
              {relatedServers.map((srv) => {
                const displayChange = relatedOverrides[srv.id]?.change ?? Math.abs(srv.change24h);
                return (
                  <div
                    key={srv.id}
                    onClick={() => onSelectServer(srv.id)}
                    className="border border-[#EAE9E4] hover:border-[#D4D3CD] rounded-2xl p-3.5 flex flex-col justify-between transition-colors cursor-pointer bg-[#FDFDFC]"
                  >
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <ServerIcon id={srv.id} variant="table" />
                        <div className="min-w-0">
                          <p className="text-[12.5px] font-semibold text-[#18181B] leading-tight">
                            {srv.ticker}
                          </p>
                          <p className="text-[10.5px] text-[#A1A1AA] truncate mt-0.5">{srv.name}</p>
                        </div>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-[#A1A1AA] shrink-0" />
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[13.5px] font-bold text-[#18181B] tabular-nums">
                          ${srv.priceUsd.toFixed(2)}
                        </span>
                        <span className="text-[11px] font-medium text-[#10B981] inline-flex items-center gap-0.5 tabular-nums">
                          <ArrowUpRight className="w-3 h-3" />+{displayChange.toFixed(1)}%
                        </span>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectServer(srv.id);
                        }}
                        className="px-3 py-1 rounded-lg border border-[#E4E3DE] bg-white hover:bg-[#F5F4F0] text-[11px] font-medium text-[#18181B] cursor-pointer"
                      >
                        Trade
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        </main>
      )}

      {/* RIGHT SIDEBAR COLUMN */}
      <aside className="w-[295px] shrink-0 space-y-4">
        {/* Trade Execution Box */}
        <section className="bg-white border border-[#EAE9E4] rounded-2xl p-5">
          <h2 className="text-[15px] font-semibold text-[#18181B] mb-3.5">Trade</h2>

          {/* Buy / Sell Segmented Switch */}
          <div className="bg-[#F4F3EF] p-1 rounded-xl grid grid-cols-2 mb-4">
            <button
              type="button"
              onClick={() => setOrderSide('buy')}
              className={`py-2 rounded-lg text-[12.5px] font-semibold transition-all cursor-pointer ${
                orderSide === 'buy'
                  ? 'bg-white text-[#10B981] shadow-[0_1px_2px_rgba(0,0,0,0.05)]'
                  : 'text-[#71717A] hover:text-[#18181B]'
              }`}
            >
              Buy
            </button>
            <button
              type="button"
              onClick={() => setOrderSide('sell')}
              className={`py-2 rounded-lg text-[12.5px] font-semibold transition-all cursor-pointer ${
                orderSide === 'sell'
                  ? 'bg-white text-[#EF4444] shadow-[0_1px_2px_rgba(0,0,0,0.05)]'
                  : 'text-[#71717A] hover:text-[#18181B]'
              }`}
            >
              Sell
            </button>
          </div>

          <form onSubmit={handleOrderSubmit} className="space-y-3.5">
            {/* Order Type */}
            <div>
              <label className="block text-[11.5px] text-[#71717A] mb-1.5">Order Type</label>
              <div className="relative">
                <select
                  value={orderType}
                  onChange={(e) => setOrderType(e.target.value as 'Market' | 'Limit' | 'Stop-Limit')}
                  className="w-full appearance-none bg-[#F8F7F4] border border-[#EAE9E4] rounded-xl px-3.5 py-2.5 text-[12.5px] font-medium text-[#18181B] focus:outline-none focus:border-[#18181B] cursor-pointer"
                >
                  <option value="Market">Market</option>
                  <option value="Limit">Limit</option>
                  <option value="Stop-Limit">Stop-Limit</option>
                </select>
                <ChevronDown className="w-4 h-4 text-[#71717A] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            {/* Amount */}
            <div>
              <label className="block text-[11.5px] text-[#71717A] mb-1.5">Amount</label>
              <div className="flex items-center bg-[#F8F7F4] border border-[#EAE9E4] rounded-xl px-3.5 py-2 focus-within:border-[#18181B]">
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={amountInput}
                  onChange={(e) => setAmountInput(e.target.value)}
                  className="w-full bg-transparent text-[13px] font-mono font-medium text-[#18181B] focus:outline-none tabular-nums"
                />
                <span className="px-2 py-0.5 rounded bg-white border border-[#EAE9E4] text-[10.5px] font-semibold text-[#52525B] shrink-0">
                  {selectedServer.ticker}
                </span>
              </div>

              {/* Percentage quick buttons */}
              <div className="grid grid-cols-4 gap-2 mt-2">
                {[25, 50, 75, 100].map((pct) => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() => handlePercentageClick(pct)}
                    className="py-1.5 rounded-lg border border-[#EAE9E4] hover:bg-[#F5F4F0] text-[11px] font-medium text-[#52525B] transition-colors cursor-pointer"
                  >
                    {pct}%
                  </button>
                ))}
              </div>
            </div>

            {/* Total (USD) */}
            <div>
              <label className="block text-[11.5px] text-[#71717A] mb-1.5">Total (USD)</label>
              <div className="bg-[#F8F7F4] border border-[#EAE9E4] rounded-xl px-3.5 py-2.5 text-[13px] font-mono text-[#71717A] tabular-nums">
                {totalUsd.toFixed(2)}
              </div>
            </div>

            {/* Available Balance */}
            <div className="flex items-center justify-between text-[11.5px] pt-0.5">
              <span className="text-[#71717A]">Available Balance</span>
              <span className="font-mono font-semibold text-[#18181B] inline-flex items-center gap-1 tabular-nums">
                <span className="text-[#71717A] font-normal">$CRED</span>{' '}
                {credBalance.toLocaleString()}
                <RefreshCw className="w-3 h-3 text-[#71717A] ml-0.5" />
              </span>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-[#141416] hover:bg-[#27272A] text-white text-[13px] font-semibold transition-colors cursor-pointer"
            >
              {orderSide === 'buy' ? 'Place Buy Order' : 'Place Sell Order'}
            </button>
          </form>
        </section>

        {/* Recent Trades Card */}
        <section className="bg-white border border-[#EAE9E4] rounded-2xl p-5">
          <h2 className="text-[14px] font-semibold text-[#18181B] mb-3">Recent Trades</h2>

          <div className="grid grid-cols-3 text-[11px] text-[#A1A1AA] pb-2 border-b border-[#F3F2EE]">
            <span>Price (USD)</span>
            <span className="text-center">Amount</span>
            <span className="text-right">Time</span>
          </div>

          <div className="divide-y divide-[#F8F7F4] mt-1">
            {trades.map((tr) => {
              const scaledPrice = +(tr.price * priceRatio).toFixed(2);
              return (
                <div
                  key={tr.id}
                  className="grid grid-cols-3 py-2 text-[11.5px] font-mono tabular-nums items-center"
                >
                  <span
                    className={`font-medium ${
                      tr.side === 'buy' ? 'text-[#10B981]' : 'text-[#EF4444]'
                    }`}
                  >
                    {scaledPrice.toFixed(2)}
                  </span>
                  <span className="text-center text-[#3F3F46]">{tr.amount}</span>
                  <span className="text-right text-[#71717A]">{tr.time}</span>
                </div>
              );
            })}
          </div>
        </section>

        {/* My Position Card */}
        <section className="bg-white border border-[#EAE9E4] rounded-2xl p-5">
          <div className="flex items-center justify-between mb-3.5">
            <h2 className="text-[14px] font-semibold text-[#18181B]">My Position</h2>
            <button
              onClick={() => onSelectTab('Portfolio')}
              className="text-[11.5px] text-[#71717A] hover:text-[#18181B] inline-flex items-center gap-1 cursor-pointer"
            >
              <span>View all</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-3">
            <div>
              <p className="text-[11px] text-[#71717A]">Holdings</p>
              <p className="text-[14.5px] font-bold text-[#18181B] tabular-nums mt-0.5">
                {holdingsCount.toLocaleString()}{' '}
                <span className="font-normal text-[#52525B]">{selectedServer.ticker}</span>
              </p>
            </div>

            <div>
              <p className="text-[11px] text-[#71717A]">Avg. Price</p>
              <p className="text-[14.5px] font-bold text-[#18181B] tabular-nums mt-0.5">
                ${avgPrice.toFixed(2)}
              </p>
            </div>

            <div>
              <p className="text-[11px] text-[#71717A]">Current Value</p>
              <p className="text-[14.5px] font-bold text-[#18181B] tabular-nums mt-0.5">
                ${selectedServer.priceUsd.toFixed(2)}
              </p>
            </div>

            <div>
              <p className="text-[11px] text-[#71717A]">P&L</p>
              <p className="text-[14.5px] font-bold text-[#10B981] inline-flex items-center gap-1 tabular-nums mt-0.5">
                <ArrowUpRight className="w-4 h-4" />+{pnlPct}%
              </p>
            </div>
          </div>
        </section>
      </aside>
    </div>
  );
};

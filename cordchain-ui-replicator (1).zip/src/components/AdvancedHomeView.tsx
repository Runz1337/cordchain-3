import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  TrendingUp,
  Zap,
  ShieldCheck,
  Users,
  Calculator,
  Play,
  ArrowUpRight,
  DollarSign,
  ChevronRight,
} from 'lucide-react';
import { ServerAsset, MainTab } from '../types';
import { ServerIcon, LeagueBadge, DiscordLogo, HeroIsometricIllustration } from './Icons';

interface AdvancedHomeViewProps {
  servers: ServerAsset[];
  ipoServers: ServerAsset[];
  onSelectTab: (tab: MainTab) => void;
  onSelectServerForTrade: (serverId: string) => void;
  onOpenBoostModal: () => void;
  onOpenVideoModal: () => void;
  onOpenDiscordLogin: () => void;
  onOpenAdModal: () => void;
}

export const AdvancedHomeView: React.FC<AdvancedHomeViewProps> = ({
  servers,
  ipoServers,
  onSelectTab,
  onSelectServerForTrade,
  onOpenBoostModal,
  onOpenVideoModal,
  onOpenDiscordLogin,
  onOpenAdModal,
}) => {
  const [memberCount, setMemberCount] = useState<number>(5000);
  const [dailyActive, setDailyActive] = useState<number>(650);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // Calculator logic
  const estimatedTokenPrice = Math.max(12, Math.round((memberCount * 0.012 + dailyActive * 0.08) * 10) / 10);
  const estimatedMarketCap = Math.round(estimatedTokenPrice * memberCount * 3.8);
  const projectedWeeklyAdDividends = Math.round(dailyActive * 1.85);

  const categories = ['All', 'AI & Tech', 'Gaming', 'Coding', 'Art & Design', 'Study'];

  const allServers = [...servers, ...ipoServers];
  const filteredServers = allServers.filter((s) => {
    if (selectedCategory === 'All') return true;
    return s.category.toLowerCase().includes(selectedCategory.toLowerCase()) ||
      s.tags.some((t) => t.toLowerCase().includes(selectedCategory.toLowerCase()));
  });

  return (
    <div className="space-y-6 select-none">
      {/* Live Market Ticker Tape */}
      <div className="bg-white border-y border-[#EAE9E4] py-2 overflow-hidden flex items-center">
        <div className="flex items-center gap-8 animate-marquee whitespace-nowrap text-[12px] font-mono px-4">
          {allServers.map((s) => (
            <button
              key={s.id}
              onClick={() => onSelectServerForTrade(s.id)}
              className="inline-flex items-center gap-2 hover:opacity-80 transition-opacity cursor-pointer shrink-0"
            >
              <span className="font-semibold text-[#18181B]">{s.ticker}</span>
              <span className="text-[#52525B]">₹{s.priceInr.toFixed(2)}</span>
              <span
                className={`font-medium ${
                  s.change24h >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'
                }`}
              >
                {s.change24h >= 0 ? '+' : ''}
                {s.change24h.toFixed(1)}%
              </span>
            </button>
          ))}
          {/* duplicate for seamless loop */}
          {allServers.map((s) => (
            <button
              key={`${s.id}-dup`}
              onClick={() => onSelectServerForTrade(s.id)}
              className="inline-flex items-center gap-2 hover:opacity-80 transition-opacity cursor-pointer shrink-0"
            >
              <span className="font-semibold text-[#18181B]">{s.ticker}</span>
              <span className="text-[#52525B]">₹{s.priceInr.toFixed(2)}</span>
              <span
                className={`font-medium ${
                  s.change24h >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'
                }`}
              >
                {s.change24h >= 0 ? '+' : ''}
                {s.change24h.toFixed(1)}%
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid Hero & Features */}
      <div className="max-w-[1440px] mx-auto px-5 space-y-6">
        {/* Interactive Discord Community Valuation Calculator */}
        <section className="bg-white border border-[#EAE9E4] rounded-2xl p-7 relative overflow-hidden">
          <div className="flex flex-wrap items-start justify-between gap-6 mb-6">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EFECE6] text-[11px] font-semibold text-[#18181B] mb-2.5">
                <Calculator className="w-3.5 h-3.5" />
                <span>CORDCHAIN VALUATION ENGINE</span>
              </div>
              <h2 className="text-[26px] font-bold text-[#18181B] tracking-tight leading-tight">
                Calculate Your Discord Server Asset Value
              </h2>
              <p className="text-[13px] text-[#71717A] max-w-xl mt-1">
                Discord servers are productive digital real estate. See how much your community shares could trade for and estimate monthly ad revenue dividends.
              </p>
            </div>

            <button
              onClick={onOpenDiscordLogin}
              className="px-5 py-2.5 rounded-xl bg-[#5865F2] hover:bg-[#4752C4] text-white text-[13px] font-semibold inline-flex items-center gap-2 transition-colors cursor-pointer"
            >
              <DiscordLogo className="w-4 h-4 text-white" />
              <span>Connect Your Server Now</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center pt-2">
            {/* Sliders on Left */}
            <div className="lg:col-span-7 space-y-5">
              <div>
                <div className="flex justify-between text-[13px] mb-2">
                  <span className="font-medium text-[#18181B]">Total Discord Members</span>
                  <span className="font-mono font-bold text-[#18181B]">{memberCount.toLocaleString()} members</span>
                </div>
                <input
                  type="range"
                  min="500"
                  max="50000"
                  step="500"
                  value={memberCount}
                  onChange={(e) => setMemberCount(Number(e.target.value))}
                  className="w-full accent-[#18181B] cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[13px] mb-2">
                  <span className="font-medium text-[#18181B]">Daily Active Chatters & Voice Users</span>
                  <span className="font-mono font-bold text-[#18181B]">{dailyActive.toLocaleString()} online</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="10000"
                  step="50"
                  value={dailyActive}
                  onChange={(e) => setDailyActive(Number(e.target.value))}
                  className="w-full accent-[#18181B] cursor-pointer"
                />
              </div>

              <div className="flex items-center gap-4 pt-2 text-[12px] text-[#71717A]">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#10B981]" />
                  <span>Verified Discord Bot Integration</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-[#EAB308]" />
                  <span>Real-time dividend pool</span>
                </div>
              </div>
            </div>

            {/* Results Card on Right */}
            <div className="lg:col-span-5 bg-[#FAF9F6] border border-[#EAE9E4] rounded-2xl p-6 space-y-4">
              <div>
                <p className="text-[11.5px] text-[#71717A]">Projected Stock Price</p>
                <p className="text-[28px] font-bold text-[#18181B] font-mono tabular-nums">
                  ₹ {estimatedTokenPrice.toFixed(2)}{' '}
                  <span className="text-[14px] text-[#71717A] font-normal">(${(estimatedTokenPrice / 83).toFixed(2)})</span>
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-[#EAE9E4]">
                <div>
                  <p className="text-[11px] text-[#71717A]">Estimated Market Cap</p>
                  <p className="text-[16px] font-bold text-[#18181B] font-mono tabular-nums">
                    ₹ {(estimatedMarketCap / 100000).toFixed(1)} Lakhs
                  </p>
                </div>
                <div>
                  <p className="text-[11px] text-[#71717A]">Weekly Ad Dividends</p>
                  <p className="text-[16px] font-bold text-[#10B981] font-mono tabular-nums">
                    +₹{projectedWeeklyAdDividends.toLocaleString()}
                  </p>
                </div>
              </div>

              <button
                onClick={onOpenBoostModal}
                className="w-full py-2.5 rounded-xl bg-[#141416] hover:bg-[#27272A] text-white text-[12.5px] font-semibold transition-colors cursor-pointer"
              >
                Apply for Server IPO Listing
              </button>
            </div>
          </div>
        </section>

        {/* Category Filter & Server Directory */}
        <section className="bg-white border border-[#EAE9E4] rounded-2xl p-6">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-5">
            <div>
              <h3 className="text-[17px] font-semibold text-[#18181B]">Explore Verified Discord Communities</h3>
              <p className="text-[12.5px] text-[#71717A]">Filter and trade shares across multiple sectors and leagues.</p>
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl text-[12px] font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    selectedCategory === cat
                      ? 'bg-[#18181B] text-white'
                      : 'bg-[#F4F3EF] text-[#52525B] hover:bg-[#EAE9E4]'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {filteredServers.map((srv) => (
              <div
                key={srv.id}
                onClick={() => onSelectServerForTrade(srv.id)}
                className="border border-[#EAE9E4] hover:border-[#C8C7C0] rounded-2xl p-4 bg-[#FCFCFA] flex flex-col justify-between transition-all hover:shadow-xs cursor-pointer"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2.5">
                      <ServerIcon id={srv.id} variant="table" />
                      <div>
                        <p className="text-[13.5px] font-bold text-[#18181B]">{srv.ticker}</p>
                        <p className="text-[11px] text-[#71717A] truncate max-w-[130px]">{srv.name}</p>
                      </div>
                    </div>
                    <LeagueBadge league={srv.league} />
                  </div>
                  <p className="text-[11.5px] text-[#52525B] line-clamp-2 mb-3">{srv.description}</p>
                </div>

                <div className="pt-3 border-t border-[#F0EFEA] flex items-center justify-between">
                  <div>
                    <span className="text-[14px] font-bold font-mono text-[#18181B]">₹{srv.priceInr.toFixed(2)}</span>
                    <span
                      className={`text-[11px] font-medium ml-1.5 ${
                        srv.change24h >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'
                      }`}
                    >
                      {srv.change24h >= 0 ? '+' : ''}{srv.change24h.toFixed(1)}%
                    </span>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectServerForTrade(srv.id);
                    }}
                    className="px-3 py-1 rounded-lg bg-[#18181B] text-white hover:bg-[#27272A] text-[11px] font-semibold"
                  >
                    Trade
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

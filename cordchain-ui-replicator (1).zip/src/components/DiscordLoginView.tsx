import React, { useState } from 'react';
import { Check, Shield, Server, ArrowRight, Key, ExternalLink } from 'lucide-react';
import { UserProfile } from '../types';
import { DiscordLogo, AyushAvatar } from './Icons';

interface DiscordLoginViewProps {
  user: UserProfile;
  onLoginSuccess: (updatedUser: Partial<UserProfile>) => void;
  onBackToApp: () => void;
}

export const DiscordLoginView: React.FC<DiscordLoginViewProps> = ({
  user,
  onLoginSuccess,
  onBackToApp,
}) => {
  const [selectedAccount, setSelectedAccount] = useState<'ayush' | 'custom'>('ayush');
  const [customUsername, setCustomUsername] = useState('');
  const [customId, setCustomId] = useState('');
  const [clientId, setClientId] = useState('123456789012345678');
  const [showDevKeys, setShowDevKeys] = useState(false);
  const [isAuthorizing, setIsAuthorizing] = useState(false);

  const handleAuthorize = () => {
    setIsAuthorizing(true);
    setTimeout(() => {
      setIsAuthorizing(false);
      if (selectedAccount === 'ayush') {
        onLoginSuccess({
          name: 'Ayush',
          username: 'ayushduoking',
          isLoggedIn: true,
        });
      } else {
        onLoginSuccess({
          name: customUsername || 'Discord Builder',
          username: (customUsername || 'builder').toLowerCase().replace(/\s+/g, ''),
          discordId: customId || '899120491823901234',
          isLoggedIn: true,
        });
      }
      onBackToApp();
    }, 800);
  };

  return (
    <div className="min-h-[calc(100vh-62px)] bg-[#F0EFEB] flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white border border-[#DFDDD6] rounded-3xl shadow-xl overflow-hidden">
        {/* Top Discord Banner */}
        <div className="bg-[#5865F2] p-7 text-white text-center relative overflow-hidden">
          <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-xs flex items-center justify-center mx-auto mb-3 shadow-inner">
            <DiscordLogo className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-[20px] font-bold">Authorize with Discord</h1>
          <p className="text-[12px] text-white/80 mt-1">
            Connect your Discord account to trade community shares on Cordchain.
          </p>
        </div>

        {/* Content Body */}
        <div className="p-7 space-y-5">
          {/* Account Selection */}
          <div>
            <p className="text-[11.5px] font-semibold text-[#71717A] uppercase tracking-wider mb-2.5">
              Choose Discord Account
            </p>

            <div className="space-y-2">
              <label
                onClick={() => setSelectedAccount('ayush')}
                className={`p-3.5 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                  selectedAccount === 'ayush'
                    ? 'border-[#5865F2] bg-[#F4F5FF]'
                    : 'border-[#EAE9E4] hover:bg-[#F9F9F7]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <AyushAvatar className="w-10 h-10" />
                  <div>
                    <p className="text-[13px] font-semibold text-[#18181B]">Ayush</p>
                    <p className="text-[11.5px] text-[#71717A]">@ayushduoking · Verified Trader</p>
                  </div>
                </div>
                {selectedAccount === 'ayush' && (
                  <span className="w-5 h-5 rounded-full bg-[#5865F2] text-white flex items-center justify-center text-[10px]">
                    ✓
                  </span>
                )}
              </label>

              <label
                onClick={() => setSelectedAccount('custom')}
                className={`p-3.5 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                  selectedAccount === 'custom'
                    ? 'border-[#5865F2] bg-[#F4F5FF]'
                    : 'border-[#EAE9E4] hover:bg-[#F9F9F7]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#EFECE6] flex items-center justify-center text-[#71717A]">
                    <DiscordLogo className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[13px] font-semibold text-[#18181B]">Switch / Custom Account</p>
                    <p className="text-[11.5px] text-[#71717A]">Log in with another Discord ID</p>
                  </div>
                </div>
                {selectedAccount === 'custom' && (
                  <span className="w-5 h-5 rounded-full bg-[#5865F2] text-white flex items-center justify-center text-[10px]">
                    ✓
                  </span>
                )}
              </label>
            </div>

            {selectedAccount === 'custom' && (
              <div className="mt-3 p-3.5 bg-[#FAF9F6] rounded-xl border border-[#EAE9E4] space-y-2.5">
                <div>
                  <label className="block text-[11px] text-[#71717A] mb-1">Discord Username</label>
                  <input
                    type="text"
                    placeholder="e.g. ServerAdmin"
                    value={customUsername}
                    onChange={(e) => setCustomUsername(e.target.value)}
                    className="w-full bg-white border border-[#EAE9E4] rounded-lg px-3 py-1.5 text-[12.5px] text-[#18181B]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#71717A] mb-1">Discord Snowflake ID</label>
                  <input
                    type="text"
                    placeholder="e.g. 741289410293817344"
                    value={customId}
                    onChange={(e) => setCustomId(e.target.value)}
                    className="w-full bg-white border border-[#EAE9E4] rounded-lg px-3 py-1.5 text-[12px] font-mono text-[#18181B]"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Permissions Granted */}
          <div className="bg-[#FAF9F6] border border-[#EAE9E4] rounded-2xl p-4 space-y-2.5">
            <p className="text-[11px] font-semibold text-[#71717A] uppercase tracking-wider">
              Permissions Requested
            </p>
            <div className="space-y-1.5 text-[12px] text-[#3F3F46]">
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-[#10B981]" />
                <span>Access your Discord username, avatar, and banner</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-[#10B981]" />
                <span>Verify guilds you own or manage to issue community shares</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-[#10B981]" />
                <span>Send daily $CRED dividend rewards and boost logs</span>
              </div>
            </div>
          </div>

          {/* Developer Credentials Dropdown */}
          <div>
            <button
              type="button"
              onClick={() => setShowDevKeys(!showDevKeys)}
              className="text-[11.5px] text-[#71717A] hover:text-[#18181B] inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Key className="w-3 h-3" />
              <span>{showDevKeys ? 'Hide Discord App Keys' : 'Configure Discord Developer Credentials (OAuth)'}</span>
            </button>

            {showDevKeys && (
              <div className="mt-2 p-3 bg-[#F8F7F4] border border-[#EAE9E4] rounded-xl text-[11.5px] space-y-2">
                <p className="text-[#52525B]">
                  For production OAuth, configure <code className="bg-white px-1 py-0.5 rounded border border-[#EAE9E4]">DISCORD_CLIENT_ID</code> in your environment:
                </p>
                <div>
                  <label className="block text-[#71717A] text-[10.5px]">Client ID</label>
                  <input
                    type="text"
                    value={clientId}
                    onChange={(e) => setClientId(e.target.value)}
                    className="w-full bg-white border border-[#EAE9E4] rounded px-2.5 py-1 text-[11px] font-mono"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="space-y-2 pt-2">
            <button
              onClick={handleAuthorize}
              disabled={isAuthorizing}
              className="w-full py-3 rounded-2xl bg-[#5865F2] hover:bg-[#4752C4] text-white text-[13.5px] font-semibold transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <DiscordLogo className="w-4 h-4 text-white" />
              <span>{isAuthorizing ? 'Authorizing...' : 'Authorize Cordchain'}</span>
            </button>

            <button
              onClick={onBackToApp}
              className="w-full py-2.5 rounded-2xl text-[12.5px] text-[#71717A] hover:text-[#18181B] cursor-pointer"
            >
              Cancel & Return to Dashboard
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

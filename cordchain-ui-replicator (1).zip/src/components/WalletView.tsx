import React from 'react';
import {
  Wallet,
  ArrowUpRight,
  ArrowRight,
  Play,
  ShieldCheck,
  Scissors,
  Gamepad2,
  Megaphone,
  ArrowUpFromLine,
} from 'lucide-react';
import { ActivityItem, ServerAsset, MainTab } from '../types';
import { ServerIcon, LeagueBadge } from './Icons';

interface WalletViewProps {
  credBalance: number;
  inrBalance: number;
  servers: ServerAsset[];
  activities: ActivityItem[];
  onSelectTab: (tab: MainTab) => void;
  onSelectServerForTrade: (serverId: string) => void;
  onOpenWithdrawModal: () => void;
  onOpenVideoModal: () => void;
  onOpenAdModal: () => void;
}

export const WalletView: React.FC<WalletViewProps> = ({
  credBalance,
  inrBalance,
  servers,
  activities,
  onSelectTab,
  onSelectServerForTrade,
  onOpenWithdrawModal,
  onOpenVideoModal,
  onOpenAdModal,
}) => {
  return (
    <div className="max-w-[1440px] mx-auto px-5 py-6 space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-[22px] font-semibold text-[#18181B]">Wallets & Portfolio</h1>
          <p className="text-[13px] text-[#71717A]">
            Manage your $CRED fantasy tokens, real INR cash rewards, and Discord server stock holdings.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenVideoModal}
            className="bg-white hover:bg-[#F5F4F0] text-[#18181B] border border-[#E4E3DE] text-[12.5px] font-medium px-4 py-2.5 rounded-xl inline-flex items-center gap-2 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Watch Ad (+250 $CRED)</span>
          </button>
          <button
            onClick={onOpenWithdrawModal}
            className="bg-[#141416] hover:bg-[#27272A] text-white text-[12.5px] font-medium px-4 py-2.5 rounded-xl inline-flex items-center gap-2 cursor-pointer"
          >
            <Wallet className="w-3.5 h-3.5" />
            <span>Withdraw INR to UPI</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="bg-[#F2F9F5] border border-[#DFEFE5] rounded-2xl p-6 flex items-center justify-between">
          <div>
            <p className="text-[12.5px] font-semibold text-[#15803D] uppercase tracking-wider mb-1">
              $CRED Fantasy Wallet
            </p>
            <p className="text-[32px] font-bold text-[#18181B] tabular-nums">
              {credBalance.toLocaleString()} <span className="text-[16px] font-normal text-[#71717A]">$CRED</span>
            </p>
            <p className="text-[12px] text-[#52525B] mt-1">
              Earned from daily server boosts and ad rewards · Use to trade server stocks or launch ads.
            </p>
          </div>
          <div className="flex flex-col gap-2 shrink-0">
            <button
              onClick={() => onSelectTab('Exchange')}
              className="px-4 py-2 rounded-xl bg-[#18181B] text-white text-[12.5px] font-medium hover:bg-[#27272A] cursor-pointer"
            >
              Trade Stocks
            </button>
            <button
              onClick={onOpenAdModal}
              className="px-4 py-2 rounded-xl bg-white border border-[#D5E6DC] text-[#18181B] text-[12.5px] font-medium hover:bg-[#F8FAF9] cursor-pointer"
            >
              Launch Ad
            </button>
          </div>
        </div>

        <div className="bg-white border border-[#EAE9E4] rounded-2xl p-6 flex items-center justify-between">
          <div>
            <p className="text-[12.5px] font-semibold text-[#71717A] uppercase tracking-wider mb-1">
              INR Real Cash Wallet
            </p>
            <p className="text-[32px] font-bold text-[#18181B] tabular-nums">
              ₹ {inrBalance.toFixed(2)}
            </p>
            <p className="text-[12px] text-[#71717A] mt-1">
              Minimum withdrawal ₹100.00 · Instant payout via UPI or Bank Transfer.
            </p>
          </div>
          <button
            onClick={onOpenWithdrawModal}
            className="px-5 py-2.5 rounded-xl bg-white border border-[#E2E1DC] hover:bg-[#F7F6F3] text-[#18181B] text-[12.5px] font-semibold cursor-pointer shrink-0"
          >
            Withdraw Cash
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-8 bg-white border border-[#EAE9E4] rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[15.5px] font-semibold text-[#18181B]">Your Server Stock Holdings (5)</h2>
            <button
              onClick={() => onSelectTab('Exchange')}
              className="text-[12px] text-[#71717A] hover:text-[#18181B] inline-flex items-center gap-1 cursor-pointer"
            >
              <span>Open Exchange</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#F0EFEA] text-[11.5px] text-[#A1A1AA]">
                <th className="py-2.5 font-normal">Server</th>
                <th className="py-2.5 font-normal">League</th>
                <th className="py-2.5 font-normal">Shares Owned</th>
                <th className="py-2.5 font-normal">Current Price</th>
                <th className="py-2.5 font-normal text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F4F3EE] text-[13px]">
              {servers.map((srv) => (
                <tr key={srv.id} className="hover:bg-[#FAF9F6]">
                  <td className="py-3.5">
                    <div className="flex items-center gap-3">
                      <ServerIcon id={srv.id} variant="table" />
                      <div>
                        <p className="font-semibold text-[#18181B]">{srv.ticker}</p>
                        <p className="text-[11px] text-[#A1A1AA]">{srv.name}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5">
                    <LeagueBadge league={srv.league} />
                  </td>
                  <td className="py-3.5 font-mono font-semibold text-[#18181B] tabular-nums">
                    {(srv.holdings ?? 1200).toLocaleString()} {srv.ticker}
                  </td>
                  <td className="py-3.5 font-mono tabular-nums">
                    <span className="font-semibold text-[#18181B]">₹ {srv.priceInr.toFixed(2)}</span>
                    <span className="ml-2 text-[11.5px] text-[#10B981] inline-flex items-center">
                      <ArrowUpRight className="w-3 h-3" />+{Math.abs(srv.change24h).toFixed(1)}%
                    </span>
                  </td>
                  <td className="py-3.5 text-right">
                    <button
                      onClick={() => onSelectServerForTrade(srv.id)}
                      className="px-3 py-1.5 rounded-lg border border-[#E4E3DE] hover:bg-[#F5F4F0] text-[12px] font-medium text-[#18181B] cursor-pointer"
                    >
                      Trade
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="lg:col-span-4 bg-white border border-[#EAE9E4] rounded-2xl p-6">
          <h2 className="text-[15.5px] font-semibold text-[#18181B] mb-4">Transaction History</h2>
          <div className="divide-y divide-[#F5F4F0]">
            {activities.map((item) => {
              const iconMap = {
                boost: <ShieldCheck className="w-4 h-4 text-[#10B981]" />,
                buy: <Scissors className="w-4 h-4 text-[#EF4444]" />,
                sell: <Gamepad2 className="w-4 h-4 text-[#EC4899]" />,
                ad: <Megaphone className="w-4 h-4 text-[#52525B]" />,
                withdraw: <ArrowUpFromLine className="w-4 h-4 text-[#52525B]" />,
              };
              return (
                <div key={item.id} className="py-3 first:pt-0 last:pb-0 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-[#F5F4F0] flex items-center justify-center">
                      {iconMap[item.type]}
                    </div>
                    <div>
                      <p className="text-[12.5px] font-medium text-[#18181B]">{item.title}</p>
                      <p
                        className={`text-[11.5px] font-medium tabular-nums ${
                          item.isPositive ? 'text-[#10B981]' : 'text-[#EF4444]'
                        }`}
                      >
                        {item.subtitle}
                      </p>
                    </div>
                  </div>
                  <span className="text-[11px] text-[#A1A1AA]">{item.timeAgo}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Store,
  Sliders,
  DollarSign,
  Users,
  Coins,
  ShieldCheck,
  Plus,
  RefreshCw,
  ArrowRight,
  TrendingUp,
  CheckCircle2,
  PieChart,
  Megaphone,
} from 'lucide-react';
import { OwnedServerStock, MainTab } from '../types';
import { DiscordLogo, ServerIcon } from './Icons';

interface ManageStockViewProps {
  ownedServer: OwnedServerStock;
  onUpdateOwnedServer: (updated: Partial<OwnedServerStock>) => void;
  onSelectTab: (tab: MainTab) => void;
  onTriggerToast: (msg: string) => void;
}

export const ManageStockView: React.FC<ManageStockViewProps> = ({
  ownedServer,
  onUpdateOwnedServer,
  onSelectTab,
  onTriggerToast,
}) => {
  const [activeSection, setActiveSection] = useState<'overview' | 'dividends' | 'issuance' | 'bot' | 'new_ipo'>(
    'overview'
  );

  // Dividend sliders
  const [shareholdersSplit, setShareholdersSplit] = useState(ownedServer.dividendSplitShareholders);
  const [treasurySplit, setTreasurySplit] = useState(ownedServer.dividendSplitTreasury);
  const [ownerSplit, setOwnerSplit] = useState(ownedServer.dividendSplitOwner);
  const [boostMultiplier, setBoostMultiplier] = useState(ownedServer.boostRewardMultiplier);
  const [adEnabled, setAdEnabled] = useState(ownedServer.adMonetizationEnabled);

  // Secondary offering form
  const [additionalShares, setAdditionalShares] = useState('10000');
  const [offeringPrice, setOfferingPrice] = useState(String(ownedServer.currentPriceInr));

  // New IPO wizard form
  const [newGuildName, setNewGuildName] = useState('');
  const [newTicker, setNewTicker] = useState('$');
  const [newSupply, setNewSupply] = useState('100000');
  const [newIpoPrice, setNewIpoPrice] = useState('20.00');

  const handleSaveDividends = () => {
    const total = shareholdersSplit + treasurySplit + ownerSplit;
    if (total !== 100) {
      onTriggerToast(`Dividend splits must sum to 100% (currently ${total}%)`);
      return;
    }
    onUpdateOwnedServer({
      dividendSplitShareholders: shareholdersSplit,
      dividendSplitTreasury: treasurySplit,
      dividendSplitOwner: ownerSplit,
      boostRewardMultiplier: boostMultiplier,
      adMonetizationEnabled: adEnabled,
    });
    onTriggerToast('Server dividend and monetization rules updated!');
  };

  const handleIssueShares = (e: React.FormEvent) => {
    e.preventDefault();
    const qty = Number(additionalShares) || 0;
    if (qty <= 0) return;

    onUpdateOwnedServer({
      totalSupply: ownedServer.totalSupply + qty,
      treasuryReserve: ownedServer.treasuryReserve + qty,
    });
    onTriggerToast(`Issued ${qty.toLocaleString()} new shares to Server Treasury!`);
  };

  const handleLaunchNewIpo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGuildName || newTicker.length < 2) {
      onTriggerToast('Please enter a valid Discord Server Name and Ticker');
      return;
    }

    onTriggerToast(`Server IPO for ${newTicker} registered for listing review!`);
    setActiveSection('overview');
  };

  return (
    <div className="max-w-[1440px] mx-auto px-5 py-6 space-y-6 select-none">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Store className="w-5 h-5 text-[#5865F2]" />
            <h1 className="text-[24px] font-bold text-[#18181B] tracking-tight">Server Stock Management</h1>
          </div>
          <p className="text-[13px] text-[#71717A]">
            Issue community shares, configure ad revenue dividend splits, and govern server treasury reserves.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveSection('new_ipo')}
            className="px-4 py-2.5 rounded-xl bg-white border border-[#EAE9E4] hover:bg-[#F8F7F4] text-[12.5px] font-semibold text-[#18181B] inline-flex items-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <Plus className="w-4 h-4" />
            <span>List Another Discord Server</span>
          </button>

          <button
            onClick={() => onSelectTab('Exchange')}
            className="px-4 py-2.5 rounded-xl bg-[#141416] hover:bg-[#27272A] text-white text-[12.5px] font-semibold inline-flex items-center gap-2 cursor-pointer"
          >
            <span>Trade on Market</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Top 4 Server Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-[#EAE9E4] rounded-2xl p-5">
          <p className="text-[11.5px] text-[#71717A] mb-1">Stock Ticker & Guild</p>
          <div className="flex items-center gap-2.5 mt-1">
            <ServerIcon id="squad" variant="header" className="w-9 h-9 rounded-xl" />
            <div>
              <p className="text-[17px] font-bold text-[#18181B] leading-tight">{ownedServer.ticker}</p>
              <p className="text-[11px] text-[#71717A]">{ownedServer.serverName}</p>
            </div>
          </div>
          <div className="mt-3 pt-2.5 border-t border-[#F3F2EE] flex items-center justify-between text-[11.5px]">
            <span className="text-[#71717A]">Members:</span>
            <span className="font-semibold text-[#18181B]">{ownedServer.membersCount.toLocaleString()}</span>
          </div>
        </div>

        <div className="bg-white border border-[#EAE9E4] rounded-2xl p-5">
          <p className="text-[11.5px] text-[#71717A] mb-1">Current Stock Price</p>
          <p className="text-[24px] font-bold font-mono text-[#18181B] tabular-nums">
            ₹{ownedServer.currentPriceInr.toFixed(2)}
          </p>
          <p className="text-[11.5px] font-medium text-[#10B981] flex items-center gap-1 mt-1">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+247% since IPO launch (₹{ownedServer.initialIpoPriceInr.toFixed(2)})</span>
          </p>
        </div>

        <div className="bg-white border border-[#EAE9E4] rounded-2xl p-5">
          <p className="text-[11.5px] text-[#71717A] mb-1">Server Treasury Reserve</p>
          <p className="text-[24px] font-bold font-mono text-[#18181B] tabular-nums">
            {ownedServer.treasuryReserve.toLocaleString()}{' '}
            <span className="text-[13px] font-normal text-[#71717A]">shares</span>
          </p>
          <p className="text-[11.5px] text-[#71717A] mt-1">
            Cash: <span className="font-semibold text-[#18181B] font-mono">₹{ownedServer.treasuryBalanceInr.toFixed(2)}</span>
          </p>
        </div>

        <div className="bg-white border border-[#EAE9E4] rounded-2xl p-5">
          <p className="text-[11.5px] text-[#71717A] mb-1">Total Dividends Distributed</p>
          <p className="text-[24px] font-bold font-mono text-[#10B981] tabular-nums">
            ₹{ownedServer.totalDividendsDistributedInr.toFixed(2)}
          </p>
          <p className="text-[11.5px] text-[#71717A] mt-1">
            Split to 1,420 community shareholders
          </p>
        </div>
      </div>

      {/* Main Workspace: Left Tabs + Right Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Navigation Rail */}
        <aside className="lg:col-span-3 space-y-1">
          {[
            { id: 'overview' as const, label: 'Overview & Cap Table', icon: <PieChart className="w-4 h-4" /> },
            { id: 'dividends' as const, label: 'Ad Revenue & Dividends', icon: <DollarSign className="w-4 h-4" /> },
            { id: 'issuance' as const, label: 'Secondary Offering / Buyback', icon: <Coins className="w-4 h-4" /> },
            { id: 'bot' as const, label: 'Discord Bot & Ad Spaces', icon: <DiscordLogo className="w-4 h-4" /> },
            { id: 'new_ipo' as const, label: 'List a New Server (IPO)', icon: <Plus className="w-4 h-4" /> },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-[13px] transition-colors cursor-pointer text-left ${
                activeSection === item.id
                  ? 'bg-[#EFECE6] text-[#18181B] font-semibold'
                  : 'text-[#52525B] hover:bg-[#EFECE6]/50 hover:text-[#18181B]'
              }`}
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </aside>

        {/* Content Box */}
        <main className="lg:col-span-9 bg-white border border-[#EAE9E4] rounded-2xl p-7 space-y-6">
          {/* Section 1: Overview & Cap Table */}
          {activeSection === 'overview' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-[16px] font-semibold text-[#18181B]">Cap Table & Share Distribution</h2>
                <p className="text-[12.5px] text-[#71717A]">
                  Overview of all outstanding shares, treasury equity, and major community holders.
                </p>
              </div>

              {/* Visual Breakdown Bar */}
              <div>
                <div className="flex justify-between text-[12px] mb-2 font-mono">
                  <span>Circulating: {ownedServer.circulatingSupply.toLocaleString()} (68.4%)</span>
                  <span>Treasury Reserve: {ownedServer.treasuryReserve.toLocaleString()} (31.6%)</span>
                </div>
                <div className="h-3 w-full bg-[#EAE9E4] rounded-full overflow-hidden flex">
                  <div style={{ width: '68.4%' }} className="bg-[#18181B]" />
                  <div style={{ width: '31.6%' }} className="bg-[#5865F2]" />
                </div>
              </div>

              {/* Top Shareholders Table */}
              <div className="border border-[#EAE9E4] rounded-2xl overflow-hidden">
                <table className="w-full text-left text-[13px]">
                  <thead className="bg-[#FAF9F6] border-b border-[#EAE9E4] text-[11.5px] text-[#71717A]">
                    <tr>
                      <th className="py-2.5 px-4 font-normal">Shareholder</th>
                      <th className="py-2.5 px-4 font-normal">Shares Held</th>
                      <th className="py-2.5 px-4 font-normal">Ownership %</th>
                      <th className="py-2.5 px-4 font-normal text-right">Value (INR)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#F4F3EE] font-mono">
                    {ownedServer.topHolders.map((holder, idx) => (
                      <tr key={idx} className="hover:bg-[#FAF9F6]">
                        <td className="py-3 px-4 font-sans font-semibold text-[#18181B]">
                          {holder.username}
                        </td>
                        <td className="py-3 px-4 text-[#18181B] tabular-nums">
                          {holder.shares.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-[#71717A] tabular-nums">{holder.pct}%</td>
                        <td className="py-3 px-4 text-right font-semibold text-[#18181B] tabular-nums">
                          ₹{(holder.shares * ownedServer.currentPriceInr).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Section 2: Dividends & Revenue Sharing */}
          {activeSection === 'dividends' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-[16px] font-semibold text-[#18181B]">Ad Revenue & Dividend Distribution</h2>
                <p className="text-[12.5px] text-[#71717A]">
                  When sponsors buy ads on your Discord server, configure how revenues are split automatically.
                </p>
              </div>

              <div className="space-y-5 p-5 rounded-2xl bg-[#FAF9F6] border border-[#EAE9E4]">
                <div>
                  <div className="flex justify-between text-[13px] mb-2">
                    <span className="font-semibold text-[#18181B]">1. Shareholders Dividend Pool</span>
                    <span className="font-mono font-bold text-[#10B981]">{shareholdersSplit}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="90"
                    value={shareholdersSplit}
                    onChange={(e) => setShareholdersSplit(Number(e.target.value))}
                    className="w-full accent-[#10B981] cursor-pointer"
                  />
                  <p className="text-[11px] text-[#71717A] mt-1">
                    Distributed pro-rata to anyone holding ${ownedServer.ticker.replace('$', '')} shares.
                  </p>
                </div>

                <div>
                  <div className="flex justify-between text-[13px] mb-2">
                    <span className="font-semibold text-[#18181B]">2. Server Treasury Fund</span>
                    <span className="font-mono font-bold text-[#5865F2]">{treasurySplit}%</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="60"
                    value={treasurySplit}
                    onChange={(e) => setTreasurySplit(Number(e.target.value))}
                    className="w-full accent-[#5865F2] cursor-pointer"
                  />
                  <p className="text-[11px] text-[#71717A] mt-1">
                    Saved in treasury reserve for Discord Nitro giveaways, tournament prize pools, and buybacks.
                  </p>
                </div>

                <div>
                  <div className="flex justify-between text-[13px] mb-2">
                    <span className="font-semibold text-[#18181B]">3. Server Owner & Moderator Pool</span>
                    <span className="font-mono font-bold text-[#18181B]">{ownerSplit}%</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="40"
                    value={ownerSplit}
                    onChange={(e) => setOwnerSplit(Number(e.target.value))}
                    className="w-full accent-[#18181B] cursor-pointer"
                  />
                  <p className="text-[11px] text-[#71717A] mt-1">
                    Paid directly to your registered UPI account weekly.
                  </p>
                </div>

                <div className="pt-2 text-right">
                  <span className="text-[12px] font-mono text-[#71717A]">
                    Total Allocated: {shareholdersSplit + treasurySplit + ownerSplit}% / 100%
                  </span>
                </div>
              </div>

              <button
                onClick={handleSaveDividends}
                className="px-6 py-2.5 rounded-xl bg-[#141416] hover:bg-[#27272A] text-white text-[13px] font-semibold cursor-pointer"
              >
                Save Dividend Rules
              </button>
            </div>
          )}

          {/* Section 3: Secondary Offering / Buyback */}
          {activeSection === 'issuance' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-[16px] font-semibold text-[#18181B]">Secondary Share Issuance & Buyback</h2>
                <p className="text-[12.5px] text-[#71717A]">
                  Raise additional community liquidity by minting new shares or use accumulated profits to buy back shares.
                </p>
              </div>

              <form onSubmit={handleIssueShares} className="p-5 rounded-2xl bg-[#FAF9F6] border border-[#EAE9E4] space-y-4">
                <h3 className="text-[14px] font-bold text-[#18181B]">Issue New Secondary Offering</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11.5px] text-[#71717A] mb-1">New Shares to Mint</label>
                    <input
                      type="number"
                      value={additionalShares}
                      onChange={(e) => setAdditionalShares(e.target.value)}
                      className="w-full bg-white border border-[#EAE9E4] rounded-xl px-3.5 py-2 text-[13px] font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11.5px] text-[#71717A] mb-1">Offering Price per Share (INR)</label>
                    <input
                      type="number"
                      value={offeringPrice}
                      onChange={(e) => setOfferingPrice(e.target.value)}
                      className="w-full bg-white border border-[#EAE9E4] rounded-xl px-3.5 py-2 text-[13px] font-mono"
                    />
                  </div>
                </div>

                <p className="text-[11.5px] text-[#71717A]">
                  Total Capital Raised:{' '}
                  <span className="font-mono font-bold text-[#18181B]">
                    ₹{(Number(additionalShares) * Number(offeringPrice)).toLocaleString()}
                  </span>
                </p>

                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#18181B] text-white text-[12.5px] font-semibold hover:bg-[#27272A] cursor-pointer"
                >
                  Mint & Release to Treasury
                </button>
              </form>
            </div>
          )}

          {/* Section 4: Discord Bot & Ad Spaces */}
          {activeSection === 'bot' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-[16px] font-semibold text-[#18181B]">Discord Bot & Ad Channel Integration</h2>
                <p className="text-[12.5px] text-[#71717A]">
                  Configure in-server engagement tools, trade tickers, and rewarded ad spots.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#F4F5FF] border border-[#DFE2FE] flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#5865F2] text-white flex items-center justify-center">
                    <DiscordLogo className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[13.5px] font-bold text-[#18181B]">Cordchain Verified Bot</p>
                    <p className="text-[11.5px] text-[#52525B]">Installed & Active in {ownedServer.serverName}</p>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-[#DCFCE7] text-[#15803D] text-[11px] font-semibold">
                  Online 🟢
                </span>
              </div>

              <div className="space-y-3">
                <label className="flex items-center justify-between p-3.5 rounded-xl border border-[#EAE9E4] bg-[#FAF9F6] cursor-pointer">
                  <div>
                    <p className="text-[13px] font-semibold text-[#18181B]">Rewarded Video Ad Slot</p>
                    <p className="text-[11.5px] text-[#71717A]">
                      Allow members to type <code className="bg-white px-1 rounded">/boost-reward</code> to watch 15s ads and credit your dividend pool.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={adEnabled}
                    onChange={(e) => setAdEnabled(e.target.checked)}
                    className="w-4 h-4 accent-[#18181B] cursor-pointer"
                  />
                </label>

                <div className="p-3.5 rounded-xl border border-[#EAE9E4] bg-[#FAF9F6]">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[13px] font-semibold text-[#18181B]">Community Boost Reward Multiplier</span>
                    <span className="font-mono font-bold text-[#5865F2]">{boostMultiplier}x</span>
                  </div>
                  <input
                    type="range"
                    min="1.0"
                    max="3.0"
                    step="0.1"
                    value={boostMultiplier}
                    onChange={(e) => setBoostMultiplier(Number(e.target.value))}
                    className="w-full accent-[#5865F2] cursor-pointer"
                  />
                </div>
              </div>

              <button
                onClick={handleSaveDividends}
                className="px-6 py-2.5 rounded-xl bg-[#141416] hover:bg-[#27272A] text-white text-[13px] font-semibold cursor-pointer"
              >
                Save Bot Settings
              </button>
            </div>
          )}

          {/* Section 5: List a New Server (IPO Wizard) */}
          {activeSection === 'new_ipo' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-[16px] font-semibold text-[#18181B]">Launch a New Discord Server IPO</h2>
                <p className="text-[12.5px] text-[#71717A]">
                  Tokenize another Discord server you own and open it for public community trading on Cordchain.
                </p>
              </div>

              <form onSubmit={handleLaunchNewIpo} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[12px] font-medium text-[#52525B] mb-1">
                      Discord Server Name
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Valorant Champions"
                      value={newGuildName}
                      onChange={(e) => setNewGuildName(e.target.value)}
                      className="w-full bg-[#FAF9F6] border border-[#EAE9E4] rounded-xl px-3.5 py-2 text-[13px] text-[#18181B]"
                    />
                  </div>

                  <div>
                    <label className="block text-[12px] font-medium text-[#52525B] mb-1">
                      Stock Ticker Symbol
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. $VALCHAMP"
                      value={newTicker}
                      onChange={(e) => setNewTicker(e.target.value.toUpperCase())}
                      className="w-full bg-[#FAF9F6] border border-[#EAE9E4] rounded-xl px-3.5 py-2 text-[13px] font-mono font-bold text-[#18181B]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[12px] font-medium text-[#52525B] mb-1">
                      Initial Total Supply
                    </label>
                    <input
                      type="number"
                      value={newSupply}
                      onChange={(e) => setNewSupply(e.target.value)}
                      className="w-full bg-[#FAF9F6] border border-[#EAE9E4] rounded-xl px-3.5 py-2 text-[13px] font-mono text-[#18181B]"
                    />
                  </div>

                  <div>
                    <label className="block text-[12px] font-medium text-[#52525B] mb-1">
                      IPO Opening Price (INR)
                    </label>
                    <input
                      type="number"
                      value={newIpoPrice}
                      onChange={(e) => setNewIpoPrice(e.target.value)}
                      className="w-full bg-[#FAF9F6] border border-[#EAE9E4] rounded-xl px-3.5 py-2 text-[13px] font-mono text-[#18181B]"
                    />
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#F4F5FF] border border-[#DFE2FE] text-[12px] text-[#5865F2] flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 shrink-0" />
                  <span>
                    Your server must have at least 500 members to qualify for public IPO exchange listing.
                  </span>
                </div>

                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-[#5865F2] hover:bg-[#4752C4] text-white text-[13px] font-semibold transition-colors cursor-pointer"
                >
                  Submit Server IPO for Verification
                </button>
              </form>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { X, Zap, Play, Wallet, Megaphone, CheckCircle2 } from 'lucide-react';
import { ServerAsset } from '../types';

interface ModalProps {
  activeModal: 'boost' | 'video' | 'withdraw' | 'ad' | null;
  onClose: () => void;
  servers: ServerAsset[];
  credBalance: number;
  inrBalance: number;
  onCompleteBoost: (serverId: string) => void;
  onCompleteVideo: () => void;
  onCompleteWithdraw: (amount: number, upiId: string) => void;
  onCompleteAd: (serverTicker: string, budgetCred: number) => void;
}

export const ActionModals: React.FC<ModalProps> = ({
  activeModal,
  onClose,
  servers,
  credBalance,
  inrBalance,
  onCompleteBoost,
  onCompleteVideo,
  onCompleteWithdraw,
  onCompleteAd,
}) => {
  const [selectedServerId, setSelectedServerId] = useState(servers[1]?.id || 'squad');
  const [upiId, setUpiId] = useState('ayush@okaxis');
  const [withdrawAmt, setWithdrawAmt] = useState('100');
  const [adTicker, setAdTicker] = useState('$SQUAD');
  const [adBudget, setAdBudget] = useState('500');

  if (!activeModal) return null;

  return (
    <div
      className="fixed inset-0 bg-black/30 backdrop-blur-[1px] z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white border border-[#EAE9E4] rounded-2xl shadow-xl w-full max-w-md p-6"
        onClick={(e) => e.stopPropagation()}
      >
        {activeModal === 'boost' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#EFECE6] flex items-center justify-center text-[#18181B]">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-[15px] font-semibold text-[#18181B]">Boost Server Stock</h3>
                  <p className="text-[11.5px] text-[#71717A]">Increase community rank & earn daily $CRED</p>
                </div>
              </div>
              <button onClick={onClose} className="p-1 text-[#71717A] hover:text-[#18181B] cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <label className="block text-[12px] font-medium text-[#52525B] mb-2">
              Select Discord Server to Boost
            </label>
            <select
              value={selectedServerId}
              onChange={(e) => setSelectedServerId(e.target.value)}
              className="w-full bg-[#F8F7F4] border border-[#EAE9E4] rounded-xl px-3.5 py-2.5 text-[13px] font-medium text-[#18181B] mb-4"
            >
              {servers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.ticker} — {s.name} (₹{s.priceInr.toFixed(2)})
                </option>
              ))}
            </select>

            <div className="p-3.5 rounded-xl bg-[#F2F9F5] border border-[#DFEFE5] text-[12px] text-[#15803D] mb-5 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Boosting rewards you with +250 $CRED and +₹3.50 instant bonus!</span>
            </div>

            <button
              onClick={() => {
                onCompleteBoost(selectedServerId);
                onClose();
              }}
              className="w-full py-2.5 rounded-xl bg-[#141416] hover:bg-[#27272A] text-white text-[13px] font-semibold cursor-pointer"
            >
              Confirm Server Boost
            </button>
          </div>
        )}

        {activeModal === 'video' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#EFECE6] flex items-center justify-center text-[#18181B]">
                  <Play className="w-4 h-4 fill-current" />
                </div>
                <div>
                  <h3 className="text-[15px] font-semibold text-[#18181B]">Watch Sponsored Server Ad</h3>
                  <p className="text-[11.5px] text-[#71717A]">15s Community Spotlight · Instant Reward</p>
                </div>
              </div>
              <button onClick={onClose} className="p-1 text-[#71717A] hover:text-[#18181B] cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="rounded-xl bg-[#18181B] text-white p-6 text-center mb-4">
              <p className="text-[11px] uppercase tracking-widest text-[#A1A1AA] mb-1">
                Featured Community Spotlight
              </p>
              <p className="text-[18px] font-bold mb-1">$SQUAD · General Community</p>
              <p className="text-[12px] text-[#D4D4D8] mb-4">
                12.4K active members · Daily gaming tournaments & stock dividends
              </p>
              <span className="inline-block px-3 py-1 rounded-full bg-[#10B981]/20 text-[#34D399] text-[11px] font-medium">
                Reward Ready: +250 $CRED + ₹3.50
              </span>
            </div>

            <button
              onClick={() => {
                onCompleteVideo();
                onClose();
              }}
              className="w-full py-2.5 rounded-xl bg-[#141416] hover:bg-[#27272A] text-white text-[13px] font-semibold cursor-pointer"
            >
              Claim Ad Reward (+250 $CRED)
            </button>
          </div>
        )}

        {activeModal === 'withdraw' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#EFECE6] flex items-center justify-center text-[#18181B]">
                  <Wallet className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-[15px] font-semibold text-[#18181B]">Withdraw INR to UPI</h3>
                  <p className="text-[11.5px] text-[#71717A]">Available: ₹ {inrBalance.toFixed(2)} (Min. ₹100)</p>
                </div>
              </div>
              <button onClick={onClose} className="p-1 text-[#71717A] hover:text-[#18181B] cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 mb-5">
              <div>
                <label className="block text-[12px] text-[#52525B] mb-1">UPI ID</label>
                <input
                  type="text"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  className="w-full bg-[#F8F7F4] border border-[#EAE9E4] rounded-xl px-3.5 py-2 text-[13px] text-[#18181B]"
                />
              </div>
              <div>
                <label className="block text-[12px] text-[#52525B] mb-1">Amount (INR)</label>
                <input
                  type="number"
                  min="100"
                  max={inrBalance}
                  value={withdrawAmt}
                  onChange={(e) => setWithdrawAmt(e.target.value)}
                  className="w-full bg-[#F8F7F4] border border-[#EAE9E4] rounded-xl px-3.5 py-2 text-[13px] font-mono text-[#18181B]"
                />
              </div>
            </div>

            <button
              onClick={() => {
                onCompleteWithdraw(Math.min(inrBalance, Math.max(100, Number(withdrawAmt) || 100)), upiId);
                onClose();
              }}
              className="w-full py-2.5 rounded-xl bg-[#141416] hover:bg-[#27272A] text-white text-[13px] font-semibold cursor-pointer"
            >
              Withdraw ₹{withdrawAmt} Instantly
            </button>
          </div>
        )}

        {activeModal === 'ad' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#EFECE6] flex items-center justify-center text-[#18181B]">
                  <Megaphone className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-[15px] font-semibold text-[#18181B]">Launch Server Ad Campaign</h3>
                  <p className="text-[11.5px] text-[#71717A]">Available: {credBalance.toLocaleString()} $CRED</p>
                </div>
              </div>
              <button onClick={onClose} className="p-1 text-[#71717A] hover:text-[#18181B] cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 mb-5">
              <div>
                <label className="block text-[12px] text-[#52525B] mb-1">Target Server Ticker</label>
                <input
                  type="text"
                  value={adTicker}
                  onChange={(e) => setAdTicker(e.target.value)}
                  className="w-full bg-[#F8F7F4] border border-[#EAE9E4] rounded-xl px-3.5 py-2 text-[13px] text-[#18181B]"
                />
              </div>
              <div>
                <label className="block text-[12px] text-[#52525B] mb-1">Campaign Budget ($CRED)</label>
                <input
                  type="number"
                  min="500"
                  step="100"
                  value={adBudget}
                  onChange={(e) => setAdBudget(e.target.value)}
                  className="w-full bg-[#F8F7F4] border border-[#EAE9E4] rounded-xl px-3.5 py-2 text-[13px] font-mono text-[#18181B]"
                />
              </div>
            </div>

            <button
              onClick={() => {
                onCompleteAd(adTicker, Math.max(500, Number(adBudget) || 500));
                onClose();
              }}
              className="w-full py-2.5 rounded-xl bg-[#141416] hover:bg-[#27272A] text-white text-[13px] font-semibold cursor-pointer"
            >
              Launch Campaign ({adBudget} $CRED)
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
